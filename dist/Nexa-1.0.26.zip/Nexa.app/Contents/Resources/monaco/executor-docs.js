//
//  executor-docs.js
//  NexaGUI — what each of this executor's functions is, in one line.
//
//  The *list* of functions is generated (tools/gen-globals.py reads src/UNC.hpp
//  and src/lua), so it can never claim something the executor does not have.
//  What a function means cannot be generated, so it is written here. A name
//  with no entry still completes and still shows its argument names; it just
//  does not carry a sentence.
//
//  Keyed by the name as it is typed. `crypt.hash` and the other library
//  members are keyed by their full path.
//

(function (global) {
  "use strict";

  global.NEXA_EXEC_DOCS = {

    // ----------------------------------------------------------- environment

    getgenv: ["getgenv(): table",
      "The executor's shared global environment. Anything put here is visible to every script this executor runs."],
    getrenv: ["getrenv(): table",
      "The game's own global environment, as the game's scripts see it."],
    getsenv: ["getsenv(script: BaseScript): table",
      "The environment of a script that is already running."],
    gettenv: ["gettenv(thread: thread): table",
      "The environment of a coroutine."],
    getreg: ["getreg(): table",
      "The Luau registry, where the engine keeps its own references."],
    getregistry: ["getregistry(): table", "Another name for `getreg`."],
    getgc: ["getgc(includeTables: boolean?): {any}",
      "Every function on the heap, and every table too when asked. Walks the collector, so it is not cheap."],
    filtergc: ["filtergc(kind: \"function\" | \"table\", options: table, returnOne: boolean?): any",
      "Searches the heap for a function or table matching the options given — constants, upvalues, a name."],
    getinstances: ["getinstances(): {Instance}",
      "Every Instance the client has a reference to, parented or not."],
    getnilinstances: ["getnilinstances(): {Instance}",
      "Every Instance whose parent is nil."],
    getscripts: ["getscripts(): {BaseScript}", "Every script the client has loaded."],
    getrunningscripts: ["getrunningscripts(): {BaseScript}", "Every script that is currently running."],
    getloadedmodules: ["getloadedmodules(): {ModuleScript}", "Every ModuleScript that has already been required."],
    getcallingscript: ["getcallingscript(): BaseScript", "The script that called the running function."],
    getscriptfromthread: ["getscriptfromthread(thread: thread): BaseScript", "The script a coroutine belongs to."],
    getactors: ["getactors(): {Actor}", "Every Actor with a Luau state of its own."],
    run_on_actor: ["run_on_actor(actor: Actor, source: string, ...): ()",
      "Runs source on an Actor's own Luau state, with our globals installed."],
    getrendersteppedlist: ["getrendersteppedlist(): {function}",
      "Everything connected to RenderStepped."],

    // --------------------------------------------------------------- closures

    checkcaller: ["checkcaller(): boolean",
      "True when the running thread is the executor's rather than the game's."],
    islclosure: ["islclosure(fn: function): boolean", "Whether the function is a Luau closure."],
    iscclosure: ["iscclosure(fn: function): boolean", "Whether the function is a C closure."],
    isexecutorclosure: ["isexecutorclosure(fn: function): boolean",
      "Whether the function came from this executor."],
    isourclosure: ["isourclosure(fn: function): boolean", "Another name for `isexecutorclosure`."],
    checkclosure: ["checkclosure(fn: function): boolean", "Another name for `isexecutorclosure`."],
    isnewcclosure: ["isnewcclosure(fn: function): boolean",
      "Whether the function is a Lua function wrapped by `newcclosure`."],
    newcclosure: ["newcclosure(fn: function): function",
      "Wraps a Lua function so it reads as a C closure to anything that inspects it."],
    newlclosure: ["newlclosure(fn: function): function", "Wraps a C closure so it reads as a Luau one."],
    clonefunction: ["clonefunction(fn: function): function",
      "An independent copy of a function: hooking the copy leaves the original alone."],
    comparefunctions: ["comparefunctions(a: function, b: function): boolean",
      "Whether two references are the same function, seeing through wrappers."],
    comparefunction: ["comparefunction(a: function, b: function): boolean", "Another name for `comparefunctions`."],
    hookfunction: ["hookfunction(target: function, hook: function): function",
      "Replaces target with hook and returns the original, so the hook can still call it."],
    hookfunc: ["hookfunc(target: function, hook: function): function", "Another name for `hookfunction`."],
    replaceclosure: ["replaceclosure(target: function, hook: function): function", "Another name for `hookfunction`."],
    restorefunction: ["restorefunction(target: function): ()", "Undoes a `hookfunction` on that function."],
    restorefunc: ["restorefunc(target: function): ()", "Another name for `restorefunction`."],
    restore_function: ["restore_function(target: function): ()", "Another name for `restorefunction`."],
    isfunctionhooked: ["isfunctionhooked(fn: function): boolean", "Whether the function is currently hooked."],
    getfunctionhash: ["getfunctionhash(fn: function): string", "A hash of the function's bytecode."],
    hookmetamethod: ["hookmetamethod(object: any, method: string, hook: function): function",
      "Hooks one metamethod of an object's metatable and returns the original."],
    getrawmetatable: ["getrawmetatable(object: any): table",
      "The metatable, ignoring `__metatable`."],
    setrawmetatable: ["setrawmetatable(object: any, metatable: table?): any",
      "Sets the metatable, ignoring `__metatable`."],
    setreadonly: ["setreadonly(t: table, readonly: boolean): ()", "Locks or unlocks a table."],
    isreadonly: ["isreadonly(t: table): boolean", "Whether a table is locked."],
    makereadonly: ["makereadonly(t: table): ()", "Locks a table."],
    makewriteable: ["makewriteable(t: table): ()", "Unlocks a table."],
    makewritable: ["makewritable(t: table): ()", "Another name for `makewriteable`."],
    getnamecallmethod: ["getnamecallmethod(): string",
      "The method name inside a `__namecall` hook."],
    setnamecallmethod: ["setnamecallmethod(name: string): ()",
      "Changes the method a `__namecall` will dispatch to."],

    // ---------------------------------------------------------------- scripts

    loadstring: ["loadstring(source: string, chunkname: string?): function?, string?",
      "Compiles Luau source and returns the chunk, or nil plus the error."],
    loadfile: ["loadfile(path: string): function?, string?", "Compiles a file from the workspace."],
    dofile: ["dofile(path: string): any", "Compiles and runs a file from the workspace."],
    decompile: ["decompile(script: BaseScript): string",
      "Reconstructs readable Luau from a script's bytecode."],
    getscriptbytecode: ["getscriptbytecode(script: BaseScript): string", "A script's compiled bytecode."],
    dumpstring: ["dumpstring(script: BaseScript): string", "Another name for `getscriptbytecode`."],
    getscriptclosure: ["getscriptclosure(script: BaseScript): function",
      "A fresh closure of a script, not the running one."],
    getscriptfunction: ["getscriptfunction(script: BaseScript): function", "Another name for `getscriptclosure`."],
    getscripthash: ["getscripthash(script: BaseScript): string", "A hash of the script's bytecode."],
    getcallbackvalue: ["getcallbackvalue(object: Instance, property: string): function?",
      "Reads a callback property, which the engine otherwise refuses to hand back."],
    getcallbackmember: ["getcallbackmember(object: Instance, property: string): function?",
      "Another spelling of `getcallbackvalue`."],
    queueonteleport: ["queueonteleport(source: string): ()",
      "Runs source automatically after the next teleport."],
    queue_on_teleport: ["queue_on_teleport(source: string): ()", "Another name for `queueonteleport`."],
    clearteleportqueue: ["clearteleportqueue(): ()", "Empties the teleport queue."],
    clearqueueonteleport: ["clearqueueonteleport(): ()", "Another name for `clearteleportqueue`."],
    clear_teleport_queue: ["clear_teleport_queue(): ()", "Another name for `clearteleportqueue`."],
    identifyexecutor: ["identifyexecutor(): string, string", "This executor's name and version."],
    getexecutorname: ["getexecutorname(): string, string", "Another name for `identifyexecutor`."],

    // ------------------------------------------------------------- instances

    cloneref: ["cloneref(instance: Instance): Instance",
      "A second reference to an Instance that fails an identity comparison against the first."],
    clonereference: ["clonereference(instance: Instance): Instance", "Another name for `cloneref`."],
    compareinstances: ["compareinstances(a: Instance, b: Instance): boolean",
      "Whether two references point at the same Instance, seeing through `cloneref`."],
    gethui: ["gethui(): Instance",
      "A container for your own UI that the game cannot enumerate."],
    get_hidden_gui: ["get_hidden_gui(): Instance", "Another name for `gethui`."],
    getcustomasset: ["getcustomasset(path: string): string",
      "A content id for a file in the workspace, usable anywhere the engine wants one."],
    isscriptable: ["isscriptable(instance: Instance, property: string): boolean",
      "Whether a property is reachable from a script."],
    setscriptable: ["setscriptable(instance: Instance, property: string, value: boolean): boolean",
      "Makes a non-scriptable property reachable, and returns what it was."],
    gethiddenproperty: ["gethiddenproperty(instance: Instance, property: string): any, boolean",
      "Reads a property the engine hides, and whether it was hidden."],
    sethiddenproperty: ["sethiddenproperty(instance: Instance, property: string, value: any): boolean",
      "Writes a property the engine hides."],
    ishiddenproperty: ["ishiddenproperty(instance: Instance, property: string): boolean",
      "Whether the property is hidden from scripts."],
    saveinstance: ["saveinstance(instance: Instance?, options: table?): ()",
      "Writes an Instance tree to the workspace as an rbxmx file."],
    saveplace: ["saveplace(options: table?): ()", "Writes the whole place to the workspace."],

    // --------------------------------------------------------------- signals

    getconnections: ["getconnections(signal: RBXScriptSignal): {table}",
      "Every connection on a signal, each with Fire, Disable, Enable and Disconnect."],
    firesignal: ["firesignal(signal: RBXScriptSignal, ...): ()",
      "Fires every connection on a signal locally."],
    replicatesignal: ["replicatesignal(signal: RBXScriptSignal, ...): ()",
      "Fires a signal so the server sees it, for the signals that replicate."],
    cansignalreplicate: ["cansignalreplicate(signal: RBXScriptSignal): boolean",
      "Whether `replicatesignal` will work on that signal."],
    getsignalwhitelist: ["getsignalwhitelist(): table", "Every signal that can be replicated."],
    getsignalarguments: ["getsignalarguments(signal: RBXScriptSignal): {string}",
      "The argument types a replicated signal expects."],
    getsignalargumentsinfo: ["getsignalargumentsinfo(signal: RBXScriptSignal): table",
      "The argument types a replicated signal expects, in full."],
    fireclickdetector: ["fireclickdetector(detector: ClickDetector, distance: number?, event: string?): ()",
      "Fires a ClickDetector as if it had been clicked."],
    fireproximityprompt: ["fireproximityprompt(prompt: ProximityPrompt): ()",
      "Triggers a ProximityPrompt without holding the key."],
    firetouchinterest: ["firetouchinterest(part: BasePart, toucher: BasePart, ended: number): ()",
      "Simulates a touch between two parts. 0 begins the touch, 1 ends it."],
    firetouchtransmitter: ["firetouchtransmitter(part: BasePart, toucher: BasePart, ended: number): ()",
      "Another name for `firetouchinterest`."],

    // ------------------------------------------------------------ filesystem

    readfile: ["readfile(path: string): string", "Reads a file from the workspace."],
    writefile: ["writefile(path: string, contents: string): ()", "Writes a file into the workspace."],
    appendfile: ["appendfile(path: string, contents: string): ()", "Appends to a file in the workspace."],
    listfiles: ["listfiles(folder: string): {string}", "Lists a folder in the workspace."],
    isfile: ["isfile(path: string): boolean", "Whether the path is a file."],
    isfolder: ["isfolder(path: string): boolean", "Whether the path is a folder."],
    makefolder: ["makefolder(path: string): ()", "Creates a folder in the workspace."],
    delfile: ["delfile(path: string): ()", "Deletes a file from the workspace."],
    delfolder: ["delfolder(path: string): ()", "Deletes a folder from the workspace."],
    openfiledialog: ["openfiledialog(options: table?): string?", "Asks the user to pick a file."],
    openfilesdialog: ["openfilesdialog(options: table?): {string}?", "Asks the user to pick several files."],
    openfolderdialog: ["openfolderdialog(options: table?): string?", "Asks the user to pick a folder."],
    savefiledialog: ["savefiledialog(content: string, options: table?): string?",
      "Asks the user where to save, and writes there."],

    // ------------------------------------------------------------------ http

    request: ["request(options: table): table",
      "An HTTP request. Yields. Takes Url, Method, Headers and Body; returns Body, StatusCode, Headers and Success."],
    http_request: ["http_request(options: table): table", "Another name for `request`."],
    "http.request": ["http.request(options: table): table", "Another name for `request`."],
    request_raw: ["request_raw(options: table): table", "`request` without the executor's own headers."],

    // ---------------------------------------------------------------- crypto

    "crypt.encrypt": ["crypt.encrypt(data: string, key: string, iv: string?, mode: string?): string, string",
      "AES encryption, returning the ciphertext and the IV."],
    "crypt.decrypt": ["crypt.decrypt(data: string, key: string, iv: string, mode: string?): string",
      "Reverses `crypt.encrypt`."],
    "crypt.hash": ["crypt.hash(data: string, algorithm: string?): string",
      "Hashes a string. sha256 by default; sha1, sha384, sha512, md5 and the sha3 family are all there."],
    "crypt.hmac": ["crypt.hmac(data: string, key: string, algorithm: string?): string", "An HMAC of a string."],
    "crypt.random": ["crypt.random(size: number): string", "Cryptographically random bytes, base64 encoded."],
    "crypt.generatebytes": ["crypt.generatebytes(size: number): string", "Random bytes, base64 encoded."],
    "crypt.generatekey": ["crypt.generatekey(): string", "A random 32-byte AES key, base64 encoded."],
    "crypt.base64encode": ["crypt.base64encode(data: string): string", "Base64, encoded."],
    "crypt.base64decode": ["crypt.base64decode(data: string): string", "Base64, decoded."],
    crypt_hash: ["crypt_hash(data: string, algorithm: string?): string", "Another name for `crypt.hash`."],
    base64encode: ["base64encode(data: string): string", "Base64, encoded."],
    base64decode: ["base64decode(data: string): string", "Base64, decoded."],
    base64_encode: ["base64_encode(data: string): string", "Base64, encoded."],
    base64_decode: ["base64_decode(data: string): string", "Base64, decoded."],
    "base64.encode": ["base64.encode(data: string): string", "Base64, encoded."],
    "base64.decode": ["base64.decode(data: string): string", "Base64, decoded."],
    lz4compress: ["lz4compress(data: string): string", "LZ4, compressed."],
    lz4decompress: ["lz4decompress(data: string, size: number): string", "LZ4, decompressed to a known size."],

    // ----------------------------------------------------------------- cache

    "cache.invalidate": ["cache.invalidate(instance: Instance): ()",
      "Drops an Instance from the reference cache, so the next lookup builds a new reference."],
    "cache.iscached": ["cache.iscached(instance: Instance): boolean", "Whether the Instance is in the cache."],
    "cache.replace": ["cache.replace(instance: Instance, replacement: Instance): ()",
      "Makes every later lookup of one Instance hand back another."],

    // ----------------------------------------------------------------- input

    isrbxactive: ["isrbxactive(): boolean", "Whether the Roblox window has focus."],
    iswindowactive: ["iswindowactive(): boolean", "Another name for `isrbxactive`."],
    isgameactive: ["isgameactive(): boolean", "Another name for `isrbxactive`."],
    mouse1click: ["mouse1click(): ()", "A full left click."],
    mouse1press: ["mouse1press(): ()", "Holds the left button down."],
    mouse1release: ["mouse1release(): ()", "Lets the left button up."],
    mouse2click: ["mouse2click(): ()", "A full right click."],
    mouse2press: ["mouse2press(): ()", "Holds the right button down."],
    mouse2release: ["mouse2release(): ()", "Lets the right button up."],
    mousemoveabs: ["mousemoveabs(x: number, y: number): ()", "Moves the pointer to a point in the window."],
    mousemoverel: ["mousemoverel(x: number, y: number): ()", "Moves the pointer by an offset."],
    mousescroll: ["mousescroll(amount: number): ()", "Scrolls the wheel."],
    keypress: ["keypress(key: number): ()", "Holds a key down, by virtual key code."],
    keyrelease: ["keyrelease(key: number): ()", "Lets a key up."],
    keyclick: ["keyclick(key: number): ()", "Presses and releases a key."],
    keytap: ["keytap(key: number): ()", "Another name for `keyclick`."],

    // -------------------------------------------------------------- rconsole

    rconsoleprint: ["rconsoleprint(text: string): ()", "Writes to Nexa's console window."],
    rconsoleinfo: ["rconsoleinfo(text: string): ()", "Writes an info line to the console."],
    rconsolewarn: ["rconsolewarn(text: string): ()", "Writes a warning to the console."],
    rconsoleerr: ["rconsoleerr(text: string): ()", "Writes an error to the console."],
    rconsoleerror: ["rconsoleerror(text: string): ()", "Another name for `rconsoleerr`."],
    rconsoleclear: ["rconsoleclear(): ()", "Empties the console."],
    rconsolecreate: ["rconsolecreate(): ()", "Opens the console window."],
    rconsoleshow: ["rconsoleshow(): ()", "Opens the console window."],
    rconsolehide: ["rconsolehide(): ()", "Closes the console window."],
    rconsoledestroy: ["rconsoledestroy(): ()", "Closes the console window."],
    rconsolesettitle: ["rconsolesettitle(title: string): ()", "Renames the console window."],
    rconsolename: ["rconsolename(title: string): ()", "Another name for `rconsolesettitle`."],
    rconsoleinput: ["rconsoleinput(): string", "Waits for a line typed into the console. Yields."],

    // -------------------------------------------------------------- clipboard

    setclipboard: ["setclipboard(text: string): ()", "Puts text on the system clipboard."],
    toclipboard: ["toclipboard(text: string): ()", "Another name for `setclipboard`."],
    getclipboard: ["getclipboard(): string", "Reads the system clipboard."],
    setrbxclipboard: ["setrbxclipboard(data: string): boolean",
      "Puts Roblox model data on the clipboard, for pasting into Studio."],

    // --------------------------------------------------------------- drawing

    "Drawing.new": ["Drawing.new(class: string): table",
      "A drawing rendered over the game. Line, Text, Image, Circle, Square, Quad or Triangle."],
    "Drawing.clear": ["Drawing.clear(): ()", "Removes every drawing."],
    "Drawing.Fonts": ["Drawing.Fonts", "The font table: UI, System, Plex, Monospace."],
    isrenderobj: ["isrenderobj(object: any): boolean", "Whether the value is a drawing."],
    getrenderproperty: ["getrenderproperty(object: table, property: string): any", "Reads a drawing's property."],
    setrenderproperty: ["setrenderproperty(object: table, property: string, value: any): ()",
      "Writes a drawing's property."],
    cleardrawcache: ["cleardrawcache(): ()", "Removes every drawing and empties the cache."],

    // ------------------------------------------------------------- websocket

    "WebSocket.connect": ["WebSocket.connect(url: string): table",
      "Opens a websocket. Yields until it connects. The result has Send, Close, OnMessage and OnClose."],
    websocket: ["websocket", "Another name for the `WebSocket` library."],
    "Signal.new": ["Signal.new(): table",
      "A signal of your own, with Connect, Once, Wait, Fire and Destroy."],

    // ------------------------------------------------------------ identities

    getthreadidentity: ["getthreadidentity(): number", "The running thread's identity."],
    setthreadidentity: ["setthreadidentity(identity: number): ()",
      "Sets the running thread's identity. 8 is what most executor code wants."],
    getidentity: ["getidentity(): number", "Another name for `getthreadidentity`."],
    setidentity: ["setidentity(identity: number): ()", "Another name for `setthreadidentity`."],
    getthreadcontext: ["getthreadcontext(): number", "Another name for `getthreadidentity`."],
    setthreadcontext: ["setthreadcontext(identity: number): ()", "Another name for `setthreadidentity`."],

    // ------------------------------------------------------------------ misc

    setfpscap: ["setfpscap(fps: number): ()", "Caps the frame rate. 0 removes the cap."],
    getfpscap: ["getfpscap(): number", "The current frame rate cap."],
    messagebox: ["messagebox(text: string, caption: string, type: number?): number",
      "Shows a native dialog and waits for an answer."],
    gethwid: ["gethwid(): string", "A stable identifier for this machine."],
    isparallel: ["isparallel(): boolean", "Whether the running thread is on a parallel Actor state."],
    create_comm_channel: ["create_comm_channel(): number, table", "A channel for talking to an Actor state."],
    get_comm_channel: ["get_comm_channel(id: number): table", "The far end of a comm channel."],

    // ---------------------------------------------------------------- debug

    "debug.getinfo": ["debug.getinfo(fn: function | number, options: string?): table",
      "Source, line, name, parameter count and more for a function or a stack level."],
    "debug.getconstants": ["debug.getconstants(fn: function): {any}", "Every constant in a Luau function."],
    "debug.getconstant": ["debug.getconstant(fn: function, index: number): any", "One constant, by index."],
    "debug.setconstant": ["debug.setconstant(fn: function, index: number, value: any): ()", "Replaces a constant."],
    "debug.getupvalues": ["debug.getupvalues(fn: function): {any}", "Every upvalue of a function."],
    "debug.getupvalue": ["debug.getupvalue(fn: function, index: number): any", "One upvalue, by index."],
    "debug.setupvalue": ["debug.setupvalue(fn: function, index: number, value: any): ()", "Replaces an upvalue."],
    "debug.getprotos": ["debug.getprotos(fn: function): {function}", "Every function defined inside this one."],
    "debug.getproto": ["debug.getproto(fn: function, index: number, active: boolean?): function",
      "One inner function, by index."],
    "debug.getstack": ["debug.getstack(level: number, index: number?): any", "A value on the Luau stack."],
    "debug.setstack": ["debug.setstack(level: number, index: number, value: any): ()", "Writes to the Luau stack."],

    getconstants: ["getconstants(fn: function): {any}", "Another name for `debug.getconstants`."],
    getconstant: ["getconstant(fn: function, index: number): any", "Another name for `debug.getconstant`."],
    setconstant: ["setconstant(fn: function, index: number, value: any): ()", "Another name for `debug.setconstant`."],
    getupvalues: ["getupvalues(fn: function): {any}", "Another name for `debug.getupvalues`."],
    getupvalue: ["getupvalue(fn: function, index: number): any", "Another name for `debug.getupvalue`."],
    setupvalue: ["setupvalue(fn: function, index: number, value: any): ()", "Another name for `debug.setupvalue`."],
    getprotos: ["getprotos(fn: function): {function}", "Another name for `debug.getprotos`."],
    getproto: ["getproto(fn: function, index: number, active: boolean?): function", "Another name for `debug.getproto`."],
    getstack: ["getstack(level: number, index: number?): any", "Another name for `debug.getstack`."],
    setstack: ["setstack(level: number, index: number, value: any): ()", "Another name for `debug.setstack`."],
    getinfo: ["getinfo(fn: function | number, options: string?): table", "Another name for `debug.getinfo`."],
    script: ["script: LocalScript",
      "The script the executor runs your code as — an unparented LocalScript named `*`."]
  };

})(typeof window !== "undefined" ? window : globalThis);
