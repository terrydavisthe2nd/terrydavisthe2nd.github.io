//
//  luau-complete.js
//  NexaGUI — completion, hover, parameter hints, symbols and folding.
//
//  Every provider here answers from the same two things: the analysis of the
//  file being edited (`luau-lexer.js`) and what is known about Roblox and this
//  executor (`luau-resolve.js`). Nothing asks the network, nothing runs a
//  language server, and the whole thing is a few milliseconds of work behind a
//  cache keyed on the model's version — a suggestion list has to appear inside
//  a keystroke or it is in the way rather than out of it.
//

(function (global) {
  "use strict";

  var Lex = global.LuauLex;
  var Grammar = global.LuauGrammar;

  var LANGUAGE = "luau";
  var resolver = null;
  var monacoRef = null;
  var tokensDisposable = null;

  // ----------------------------------------------------------- the analysis

  var cache = [];
  var CACHE_SIZE = 6;
  // Past this the file is not a script any more, it is a dump. Offer the
  // globals and skip the walk rather than spend a frame on every keystroke.
  var MAX_ANALYSED = 2 * 1024 * 1024;

  function analyse(model) {
    var key = model.id + ":" + model.getVersionId();
    for (var i = 0; i < cache.length; i++) {
      if (cache[i].key === key) { return cache[i].value; }
    }
    var text = model.getValue();
    var value;
    if (text.length > MAX_ANALYSED) {
      value = Lex.analyse("", resolver);
    } else {
      value = Lex.analyse(text, resolver);
    }
    cache.unshift({ key: key, value: value });
    if (cache.length > CACHE_SIZE) { cache.pop(); }
    return value;
  }

  // ---------------------------------------------------------------- helpers

  function kindOf(name) {
    var K = monacoRef.languages.CompletionItemKind;
    switch (name) {
      case "property":   return K.Property;
      case "method":     return K.Method;
      case "event":      return K.Event;
      case "function":   return K.Function;
      case "field":      return K.Field;
      case "enum":       return K.Enum;
      case "enummember": return K.EnumMember;
      case "class":      return K.Class;
      case "variable":   return K.Variable;
      case "parameter":  return K.Variable;
      case "constant":   return K.Constant;
      case "keyword":    return K.Keyword;
      case "snippet":    return K.Snippet;
      case "module":     return K.Module;
      default:           return K.Value;
    }
  }

  /// A suggestion. `call` decides whether accepting it types the brackets too
  /// and opens the parameter hints, which is the difference between picking a
  /// method and having to remember its arguments.
  function item(spec, range, followedByParen) {
    var out = {
      label: spec.label,
      kind: kindOf(spec.kind),
      insertText: spec.insert !== undefined ? spec.insert : spec.label,
      range: range,
      sortText: spec.sort || spec.label
    };
    if (spec.detail) { out.detail = spec.detail; }
    if (spec.doc || spec.note) {
      out.documentation = { value: documentationFor(spec), isTrusted: false };
    }
    if (spec.snippet) {
      out.insertTextRules = monacoRef.languages.CompletionItemInsertTextRule.InsertAsSnippet;
    }
    if (spec.deprecated) {
      out.tags = [monacoRef.languages.CompletionItemTag.Deprecated];
    }
    if (spec.call && !followedByParen) {
      out.insertText = spec.label + (spec.noArgs ? "()" : "($1)");
      out.insertTextRules = monacoRef.languages.CompletionItemInsertTextRule.InsertAsSnippet;
      out.command = { id: "editor.action.triggerParameterHints", title: "" };
    }
    if (spec.filter) { out.filterText = spec.filter; }
    return out;
  }

  function documentationFor(spec) {
    var parts = [];
    if (spec.doc) { parts.push(spec.doc); }
    if (spec.note) { parts.push("\n\n_" + spec.note + "_"); }
    return parts.join("");
  }

  // ------------------------------------------------------------- completion

  function completionProvider() {
    return {
      triggerCharacters: [".", ":", '"', "'", "("],

      provideCompletionItems: function (model, position) {
        if (!resolver) { return { suggestions: [] }; }
        var offset = model.getOffsetAt(position);
        var analysis = analyse(model);
        var word = model.getWordUntilPosition(position);
        var range = {
          startLineNumber: position.lineNumber, endLineNumber: position.lineNumber,
          startColumn: word.startColumn, endColumn: word.endColumn
        };
        var line = model.getLineContent(position.lineNumber);
        var followedByParen = line.charAt(word.endColumn - 1) === "(";
        var context = analysis.contextAt(offset);

        if (context.kind === "comment") { return { suggestions: [] }; }

        if (context.kind === "string") {
          return { suggestions: stringSuggestions(analysis, offset, position, model, context) };
        }

        var member = analysis.memberContext(offset);
        if (member) {
          return {
            suggestions: memberSuggestions(member, range, followedByParen),
            // A member list is complete for the type it came from: there is
            // nothing more to fetch if the user types another letter.
            incomplete: false
          };
        }

        // A name being declared is not a name to complete: `local wid|` should
        // not offer `widgets` from three lines down.
        if (/(\blocal\s+[A-Za-z_0-9,\s]*|\bfunction\s+)$/.test(line.slice(0, word.startColumn - 1))) {
          return { suggestions: [] };
        }

        return { suggestions: globalSuggestions(analysis, offset, range, followedByParen) };
      }
    };
  }

  function memberSuggestions(member, range, followedByParen) {
    var members = resolver.membersOf(member.type, member.separator);
    var out = [];
    for (var i = 0; i < members.length; i++) {
      var m = members[i];
      out.push(item({
        label: m.name,
        kind: m.kind,
        detail: m.detail,
        doc: m.doc,
        note: m.note,
        sort: m.sort || m.name,
        deprecated: m.deprecated,
        call: m.call,
        noArgs: m.call && m.params && m.params.length === 0
      }, range, followedByParen));
    }
    return out;
  }

  function stringSuggestions(analysis, offset, position, model, context) {
    var call = analysis.stringCallName(context.token.s);
    if (!call) { return []; }
    var choices = resolver.stringChoices(call);
    if (!choices) { return []; }

    // The range is the string's contents, so picking a name replaces whatever
    // was half-typed rather than appending to it.
    var token = context.token;
    var start = model.getPositionAt(token.s + 1);
    var end = position;
    var range = {
      startLineNumber: start.lineNumber, startColumn: start.column,
      endLineNumber: end.lineNumber, endColumn: end.column
    };
    var out = [];
    for (var i = 0; i < choices.list.length; i++) {
      out.push({
        label: choices.list[i],
        kind: kindOf(choices.kind),
        detail: choices.detail,
        insertText: choices.list[i],
        range: range,
        sortText: choices.list[i]
      });
    }
    return out;
  }

  function globalSuggestions(analysis, offset, range, followedByParen) {
    var out = [];
    var seen = Object.create(null);

    // 1. What is in scope here, nearest first.
    var locals = Lex.localsAt(analysis.root, offset);
    for (var i = 0; i < locals.length; i++) {
      var local = locals[i];
      if (seen[local.name]) { continue; }
      seen[local.name] = 1;
      var detail = local.params
        ? "(" + local.params.join(", ") + ")"
        : Lex.typeLabel(local.type);
      out.push(item({
        label: local.name,
        kind: local.kind === "function" ? "function"
            : (local.kind === "parameter" ? "parameter" : "variable"),
        detail: detail,
        doc: local.kind === "parameter" ? "A parameter of the enclosing function."
                                        : "Declared in this file.",
        sort: "1" + pad(local.depth) + local.name,
        call: local.kind === "function",
        noArgs: local.kind === "function" && local.params && local.params.length === 0
      }, range, followedByParen));
    }

    // 2. Everything the executor and the engine provide.
    var provided = providedNames();
    for (var p = 0; p < provided.length; p++) {
      var entry = provided[p];
      if (seen[entry.label]) { continue; }
      seen[entry.label] = 1;
      out.push(item(entry, range, followedByParen));
    }

    // 3. Services, as the call that actually fetches one. A bare `Players` is
    // not a global in Luau, so offering the name alone would be a lie; this
    // types `game:GetService("Players")` instead.
    var services = resolver.ready() ? resolver.serviceNames : [];
    for (var s = 0; s < services.length; s++) {
      if (seen[services[s]]) { continue; }
      out.push(item({
        label: services[s],
        kind: "class",
        detail: "game:GetService(\"" + services[s] + "\")",
        doc: "Inserts the `GetService` call. Services are not globals; they are fetched.",
        insert: "game:GetService(\"" + services[s] + "\")",
        sort: "4" + services[s]
      }, range, followedByParen));
    }

    // 4. Keywords and snippets, together, so `for` and the `for` loop are next
    // to each other.
    var keywords = Object.keys(Lex.KEYWORDS);
    for (var k = 0; k < keywords.length; k++) {
      out.push(item({
        label: keywords[k], kind: "keyword", detail: "keyword", sort: "5" + keywords[k]
      }, range, followedByParen));
    }
    return out;
  }

  function pad(depth) {
    return depth < 10 ? "0" + depth : String(Math.min(depth, 99));
  }

  /// The full description from api-docs.js when it has loaded, else the
  /// summary. The list is rebuilt when either file arrives.
  function fullDoc(key, summary) {
    var docs = global.NEXA_API_DOCS;
    return (docs && docs[key]) || summary;
  }

  /// The global list, built once. It only changes when api.js arrives.
  var providedCache = null;

  function providedNames() {
    if (providedCache) { return providedCache; }
    var out = [];
    var G = global.NEXA_GLOBALS;
    var docs = global.NEXA_EXEC_DOCS || {};

    if (G) {
      for (var i = 0; i < G.executor.length; i++) {
        var name = G.executor[i];
        var doc = docs[name];
        var sig = G.signatures ? G.signatures[name] : null;
        out.push({
          label: name,
          kind: "function",
          detail: doc ? doc[0] : (sig ? name + "(" + sig.join(", ") + ")" : "executor"),
          doc: doc ? doc[1] : "Provided by the executor.",
          sort: "3" + name,
          call: name !== "script",
          noArgs: !!(sig && sig.length === 0)
        });
      }
      for (var lib in G.libraries) {
        var libDoc = docs[lib];
        out.push({
          label: lib, kind: "module",
          detail: "executor library",
          doc: libDoc ? libDoc[1] : ("Members: " + G.libraries[lib].join(", ") + "."),
          sort: "3" + lib
        });
      }
    }

    if (resolver && resolver.ready()) {
      var api = resolver.api;
      var g = api.globals;
      for (var f = 0; f < g.funcs.length; f++) {
        var row = g.funcs[f];
        out.push({
          label: row[0], kind: "function",
          detail: LuauResolve.withReturn(row[0] + LuauResolve.formatParams(row[1]), row[2]),
          doc: fullDoc(row[0], row[3]), sort: "3" + row[0], call: true, noArgs: row[1].length === 0
        });
      }
      for (var v = 0; v < g.props.length; v++) {
        out.push({
          label: g.props[v][0], kind: "variable",
          detail: g.props[v][1] || undefined, doc: fullDoc(g.props[v][0], g.props[v][2]),
          sort: "3" + g.props[v][0]
        });
      }
      for (var libName in api.libraries) {
        out.push({
          label: libName, kind: "module", detail: "Luau library",
          doc: fullDoc(libName, api.libraries[libName].sum), sort: "3" + libName
        });
      }
      for (var dt in api.datatypes) {
        out.push({
          label: dt, kind: "class", detail: "datatype",
          doc: fullDoc(dt, api.datatypes[dt].sum), sort: "3" + dt
        });
      }
      out.push({ label: "Enum", kind: "enum", detail: "Enum", doc: "Every enumeration the engine defines.", sort: "3Enum" });
    }

    providedCache = out;
    return out;
  }

  // ------------------------------------------------------------------ hover

  function hoverProvider() {
    return {
      provideHover: function (model, position) {
        if (!resolver) { return null; }
        var word = model.getWordAtPosition(position);
        if (!word) { return null; }
        var offset = model.getOffsetAt(position);
        var analysis = analyse(model);
        if (analysis.contextAt(offset).kind === "comment") { return null; }

        var range = new monacoRef.Range(position.lineNumber, word.startColumn,
                                        position.lineNumber, word.endColumn);
        var wordEnd = model.getOffsetAt({
          lineNumber: position.lineNumber, column: word.endColumn
        });

        // A member: resolve what it hangs off, then ask what the member is.
        var member = analysis.memberContext(wordEnd);
        if (member) {
          var described = resolver.describeMember(member.type, word.word);
          if (described) { return card(range, described.label, described.doc, described.note); }
          return card(range, word.word, "", Lex.typeLabel(member.type) + " member");
        }

        // A local?
        var scope = Lex.scopeAt(analysis.root, offset);
        var entry = analysis.lookup(scope, word.word, offset);
        if (entry) {
          var label = entry.params
            ? entry.name + "(" + entry.params.join(", ") + ")"
            : entry.name + ": " + Lex.typeLabel(entry.type);
          var note = entry.kind === "parameter" ? "parameter" : "local";
          return card(range, label, "", note);
        }

        var globalDoc = resolver.describeGlobal(word.word);
        if (globalDoc) {
          return card(range, globalDoc.label, globalDoc.doc,
                      globalDoc.exec ? "this executor" : null);
        }
        return null;
      }
    };
  }

  function card(range, signature, doc, note) {
    var contents = [{ value: "```luau\n" + signature + "\n```" }];
    if (doc) { contents.push({ value: doc }); }
    if (note) { contents.push({ value: "_" + note + "_" }); }
    return { range: range, contents: contents };
  }

  // -------------------------------------------------------- parameter hints

  function signatureProvider() {
    return {
      signatureHelpTriggerCharacters: ["(", ","],
      signatureHelpRetriggerCharacters: [","],

      provideSignatureHelp: function (model, position) {
        if (!resolver) { return null; }
        var offset = model.getOffsetAt(position);
        var analysis = analyse(model);
        if (analysis.contextAt(offset).kind === "comment") { return null; }
        var call = analysis.callContext(offset);
        if (!call) { return null; }
        var signature = resolver.signatureFor(call);
        if (!signature) { return null; }

        var ranges = paramRanges(signature.label, signature.params.length);
        var parameters = [];
        for (var i = 0; i < signature.params.length; i++) {
          parameters.push({
            label: ranges[i] || signature.params[i][0],
            documentation: signature.params[i][1] ? { value: signature.params[i][1] } : undefined
          });
        }
        return {
          value: {
            signatures: [{
              label: signature.label,
              documentation: signature.doc ? { value: signature.doc } : undefined,
              parameters: parameters
            }],
            activeSignature: 0,
            activeParameter: Math.min(call.argument, Math.max(parameters.length - 1, 0))
          },
          dispose: function () {}
        };
      }
    };
  }

  /// Where each parameter sits inside the signature's label, so the hint can
  /// underline the one being typed. Monaco takes a [start, end) pair, and a
  /// pair is exact where a substring search would land on the wrong `x`.
  function paramRanges(label, count) {
    var open = label.indexOf("(");
    var close = label.lastIndexOf(")");
    if (open < 0 || close < open) { return []; }
    var ranges = [];
    var depth = 0;
    var start = open + 1;
    for (var i = open + 1; i <= close; i++) {
      var c = label.charAt(i);
      if (c === "(" || c === "{" || c === "[") { depth++; continue; }
      if (i === close || (c === "," && depth === 0)) {
        var from = start;
        while (from < i && label.charAt(from) === " ") { from++; }
        ranges.push([from, i]);
        start = i + 1;
        continue;
      }
      if (c === ")" || c === "}" || c === "]") { depth--; }
    }
    return ranges.slice(0, count);
  }

  // ---------------------------------------------------- symbols and folding

  function symbolProvider() {
    return {
      provideDocumentSymbols: function (model) {
        var analysis = analyse(model);
        var out = [];
        for (var i = 0; i < analysis.symbols.length; i++) {
          var s = analysis.symbols[i];
          var from = model.getPositionAt(s.start);
          var to = model.getPositionAt(s.end);
          var range = new monacoRef.Range(from.lineNumber, from.column, to.lineNumber, to.column);
          out.push({
            name: s.name,
            detail: "",
            kind: monacoRef.languages.SymbolKind.Function,
            tags: [],
            range: range,
            selectionRange: range
          });
        }
        return out;
      }
    };
  }

  function foldingProvider() {
    return {
      provideFoldingRanges: function (model) {
        var analysis = analyse(model);
        var out = [];
        for (var i = 0; i < analysis.folds.length; i++) {
          var fold = analysis.folds[i];
          var from = model.getPositionAt(fold.start).lineNumber;
          var to = model.getPositionAt(fold.end).lineNumber;
          if (to > from) { out.push({ start: from, end: to - 1 }); }
        }
        return out;
      }
    };
  }

  // ---------------------------------------------------------------- install

  var installed = false;

  function install(monaco) {
    monacoRef = monaco;
    resolver = global.LuauResolve.create();

    if (!installed) {
      monaco.languages.register({
        id: LANGUAGE,
        extensions: [".lua", ".luau", ".txt"],
        aliases: ["Luau", "luau", "Lua"]
      });
      monaco.languages.setLanguageConfiguration(LANGUAGE, Grammar.configuration);
      monaco.languages.registerCompletionItemProvider(LANGUAGE, completionProvider());
      monaco.languages.registerHoverProvider(LANGUAGE, hoverProvider());
      monaco.languages.registerSignatureHelpProvider(LANGUAGE, signatureProvider());
      monaco.languages.registerDocumentSymbolProvider(LANGUAGE, symbolProvider());
      monaco.languages.registerFoldingRangeProvider(LANGUAGE, foldingProvider());
      installed = true;
    }
    refreshGrammar();
  }

  /// Re-registers the grammar with whatever word lists are available now. It
  /// is called once at boot with the executor's surface, and again when api.js
  /// arrives with every class, service and datatype name.
  function refreshGrammar() {
    if (!monacoRef) { return; }
    var lists = Grammar.wordLists(global.NEXA_GLOBALS, global.NEXA_API || null);
    var next = monacoRef.languages.setMonarchTokensProvider(LANGUAGE, Grammar.grammar(lists));
    if (tokensDisposable) { tokensDisposable.dispose(); }
    tokensDisposable = next;
  }

  /// Called once api.js has been fetched: the resolver picks up the tables,
  /// the grammar picks up the names, and the global suggestion list is built
  /// again with the engine's own globals in it.
  function apiLoaded() {
    resolver = global.LuauResolve.create();
    providedCache = null;
    cache.length = 0;
    refreshGrammar();
  }

  /// Called once api-docs.js has been fetched. The resolver reads the
  /// descriptions at the moment it is asked, so only the built list needs
  /// making again.
  function docsLoaded() {
    providedCache = null;
  }


  /// Nothing to bind any more. Enter used to be taken here so that a block
  /// could close itself, and it is Monaco's own again: an editor whose job is
  /// to say what is wrong with a script has no business writing part of one.
  function attach() {}

  global.LuauLanguage = {
    install: install,
    attach: attach,
    apiLoaded: apiLoaded,
    docsLoaded: docsLoaded,
    analyse: analyse,
    resolver: function () { return resolver; },
    paramRanges: paramRanges
  };

})(typeof window !== "undefined" ? window : globalThis);
