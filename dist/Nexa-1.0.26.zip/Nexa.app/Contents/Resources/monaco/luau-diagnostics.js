//
//  luau-diagnostics.js
//  What is actually wrong with this file.
//
//  Two layers, with two different guarantees.
//
//  The first is exact. nexa-luaucheck parses and compiles the buffer with the
//  Luau the executor loads scripts with, so a marker from it is a script that
//  cannot run, and no marker is a script that can. Its answers arrive from
//  Swift; this file asks the questions and turns the answers into markers.
//
//  The second is conservative, lives in `namesIn` below, and runs only when
//  the first found nothing — a file that does not parse has a scope tree built
//  out of guesses, and guesses are where false positives come from.
//
//  Every marker is an Error. There are no warnings, no hints and no
//  suggestions here on purpose: the editor should not have opinions about
//  style, and it cannot have an opinion about a game that is not on this
//  machine. `workspace.Anything` is unknowable and is left alone.
//
//  No DOM, no `monaco` at load: tests/gui/run.sh lang loads this exact file
//  under jsc, which has none of them — not even setTimeout.
//

(function (global) {
  "use strict";

  var SYNTAX = "luau-syntax";
  var NAMES = "luau-names";

  // Long enough that a line being typed is not underlined while it is being
  // typed, short enough that the editor looks like it noticed.
  var DEBOUNCE_MS = 350;
  // Past this the file is a dump, not a script.
  var MAX_CHECKED = 4 * 1024 * 1024;
  var MAX_NAME_MARKERS = 20;

  var monacoRef = null;
  var sendFn = null;
  var watched = Object.create(null);   // model id -> { model, timer, sent, marks }
  var enabled = true;
  var namesEnabled = true;

  // -------------------------------------------------------------- conversion

  /// The checker already answers in Monaco's coordinates — 1-based, columns in
  /// UTF-16 code units — so this only fills in the fields Monaco wants.
  function toMarkers(monaco, errors) {
    var out = [];
    for (var i = 0; i < errors.length; i++) {
      var e = errors[i];
      var endLine = e.endLine || e.line;
      var endColumn = e.endColumn || e.column;
      // A zero-width range is an invisible squiggle.
      if (endLine === e.line && endColumn <= e.column) { endColumn = e.column + 1; }
      out.push({
        severity: monaco.MarkerSeverity.Error,
        message: e.message,
        source: "luau",
        startLineNumber: e.line,
        startColumn: e.column,
        endLineNumber: endLine,
        endColumn: endColumn
      });
    }
    return out;
  }

  /// Luau's hot comments, which only count above the first statement. The ones
  /// honoured here are the escape hatch for the name checks: `--!nocheck`
  /// turns them off, `--!nolint Name` turns one of them off.
  function directives(text) {
    var out = { nocheck: false, nolint: { all: false } };
    var lines = String(text).split("\n");
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].replace(/^\s+/, "").replace(/\s+$/, "");
      if (line === "") { continue; }
      if (line.indexOf("--") !== 0) { break; }        // the header is over
      if (line.indexOf("--!") !== 0) { continue; }    // an ordinary comment
      var body = line.slice(3);
      if (body === "nocheck") { out.nocheck = true; }
      else if (body === "nolint") { out.nolint.all = true; }
      else if (body.indexOf("nolint ") === 0) {
        var names = body.slice(7).split(/\s+/);
        for (var n = 0; n < names.length; n++) {
          if (names[n]) { out.nolint[names[n]] = true; }
        }
      }
    }
    return out;
  }

  // -------------------------------------------------------------- scheduling

  function clearMarkers(id) {
    var entry = watched[id];
    if (!monacoRef || !entry || !entry.model) { return; }
    monacoRef.editor.setModelMarkers(entry.model, SYNTAX, []);
    monacoRef.editor.setModelMarkers(entry.model, NAMES, []);
    mark(entry, []);
  }

  /// The red x beside the line number.
  ///
  /// Monaco draws a marker as a wavy underline through the code itself, which
  /// is noise in the middle of what someone is reading. The markers are still
  /// set - they carry the message, and the hover comes with them - but the
  /// squiggle is turned off in the page's CSS, and the line is marked in the
  /// glyph margin instead. One mark per line however many errors are on it,
  /// with every message on the hover.
  function mark(entry, diagnostics) {
    if (!monacoRef || !entry || !entry.model) { return; }
    var byLine = Object.create(null);
    var lines = [];
    for (var i = 0; i < diagnostics.length; i++) {
      var line = diagnostics[i].line;
      if (!byLine[line]) { byLine[line] = []; lines.push(line); }
      byLine[line].push(diagnostics[i].message);
    }
    var decorations = [];
    for (var n = 0; n < lines.length; n++) {
      decorations.push({
        range: new monacoRef.Range(lines[n], 1, lines[n], 1),
        options: {
          isWholeLine: true,
          glyphMarginClassName: "nexa-error-glyph",
          // No glyphMarginHoverMessage: Monaco shows it from the empty margin
          // below the last line too. The page draws the mark's hover itself,
          // from messagesAt().
          overviewRuler: {
            color: "#FF5F56",
            position: monacoRef.editor.OverviewRulerLane.Right
          }
        }
      });
    }
    entry.marks = entry.model.deltaDecorations(entry.marks || [], decorations);
    entry.byLine = byLine;
  }

  /// The messages behind the mark on `line`, for the hover.
  function messagesAt(id, line) {
    var entry = watched[id];
    if (!entry || !entry.byLine) { return []; }
    return (entry.byLine[line] || []).slice();
  }

  function alive(model) {
    return model && !(model.isDisposed && model.isDisposed());
  }

  function ask(id) {
    var entry = watched[id];
    if (!entry || !enabled || !sendFn || !alive(entry.model)) { return; }
    var text = entry.model.getValue();
    if (text.length > MAX_CHECKED) { return; }
    entry.sent = entry.model.getVersionId();
    sendFn({ type: "check", id: id, version: entry.sent, text: text });
  }

  function schedule(id, delay) {
    var entry = watched[id];
    if (!entry || !enabled) { return; }
    if (entry.timer) { global.clearTimeout(entry.timer); entry.timer = null; }
    if (!delay) { ask(id); return; }
    entry.timer = global.setTimeout(function () {
      entry.timer = null;
      ask(id);
    }, delay);
  }

  function install(monaco, send) {
    monacoRef = monaco;
    sendFn = send;
  }

  function watch(id, model) {
    watched[id] = { model: model, timer: null, sent: 0, marks: [] };
    schedule(id, 0);
  }

  function touch(id) { schedule(id, DEBOUNCE_MS); }

  function forget(id) {
    var entry = watched[id];
    if (entry && entry.timer) { global.clearTimeout(entry.timer); }
    delete watched[id];
  }

  /// An answer from the checker. Dropped unless it is about the text that is on
  /// screen right now — during a burst of typing more than one answer can be in
  /// flight, and a stale one would put squiggles on lines that have moved.
  function receive(id, version, payload) {
    var entry = watched[id];
    if (!entry || !monacoRef || !enabled || !alive(entry.model)) { return; }
    var model = entry.model;
    if (model.getVersionId() !== version) {
      // The buffer moved while the answer was in flight, so the answer
      // describes text that is no longer there and has to go. But dropping it
      // and stopping leaves the file unchecked until the next keystroke -
      // which is how a *restored* tab came up with no marks at all on it, its
      // one check having been asked before the session finished writing the
      // text. Ask again for what is there now.
      schedule(id, DEBOUNCE_MS);
      return;
    }

    var errors;
    try { errors = JSON.parse(payload).errors || []; }
    catch (e) { return; }

    monacoRef.editor.setModelMarkers(model, SYNTAX, toMarkers(monacoRef, errors));
    // The name checks only mean anything on a file that parses.
    var found = errors.slice();
    if (errors.length === 0) {
      found = applyNames(entry);
    } else {
      monacoRef.editor.setModelMarkers(model, NAMES, []);
    }
    mark(entry, found);
  }

  /// The second layer, against the model. Reached only through `receive`, and
  /// only when the checker found nothing.
  function applyNames(entry) {
    var model = entry.model;
    if (!monacoRef) { return []; }
    if (!namesEnabled || !global.LuauLanguage) {
      monacoRef.editor.setModelMarkers(model, NAMES, []);
      return [];
    }
    var found = namesIn(global.LuauLanguage.analyse(model),
                        global.LuauLanguage.resolver(), model.getValue());
    var markers = [];
    for (var i = 0; i < found.length && i < MAX_NAME_MARKERS; i++) {
      var start = model.getPositionAt(found[i].start);
      var end = model.getPositionAt(found[i].end);
      markers.push({
        severity: monacoRef.MarkerSeverity.Error,
        message: found[i].message,
        source: "luau",
        startLineNumber: start.lineNumber, startColumn: start.column,
        endLineNumber: end.lineNumber, endColumn: end.column
      });
    }
    monacoRef.editor.setModelMarkers(model, NAMES, markers);
    return markers.map(function (m) {
      return { line: m.startLineNumber, message: m.message };
    });
  }

  function setEnabled(flag) {
    enabled = !!flag;
    for (var id in watched) {
      if (!enabled) { clearMarkers(id); } else { schedule(id, 0); }
    }
  }

  function setNames(flag) {
    namesEnabled = !!flag;
    for (var id in watched) {
      if (!namesEnabled) {
        if (monacoRef) {
          monacoRef.editor.setModelMarkers(watched[id].model, NAMES, []);
          mark(watched[id], []);
        }
      } else {
        schedule(id, 0);
      }
    }
  }

  // ---------------------------------------------------------- the name checks
  //
  // Two questions, both answered from tables: is this name anything at all,
  // and does this library have this member. Everything else about a Luau file
  // is unknowable from here and is left alone - above all what is inside
  // someone's game, which is why an Instance is never asked about.
  //
  // Every rule below is a reason to stay quiet. A name is reported only when
  // the file gives no indication whatsoever that it might exist: not a local,
  // not an assignment, not a write through getgenv, not a guard, not even a
  // string with that name in it.

  var Lex = global.LuauLex;

  // The env tables whose fields are globals: `getgenv().x = 1` defines `x`.
  var ENV_CALLS = { getgenv: 1, getrenv: 1, getfenv: 1 };
  var ENV_TABLES = { _G: 1, shared: 1 };
  // A name in one of these positions is being tested for existence, not used.
  var GUARD_BEFORE = { "if": 1, elseif: 1, "while": 1, "and": 1, "or": 1,
                       "not": 1, "return": 1, "until": 1 };
  var GUARD_AFTER = { "and": 1, "or": 1, "==": 1, "~=": 1 };
  var TYPE_CALLS = { type: 1, typeof: 1, rawget: 1, rawequal: 1 };
  // The executor's own primitives. They are real globals, but they are kept
  // out of getgenv()'s enumeration on purpose, so gen-globals.py never sees
  // them and the tables cannot know them. Anything in that namespace is ours.
  var PRIVATE_PREFIX = /^__nexa_/;
  // The types whose members are a fixed table the engine ships: a library, an
  // executor library, a datatype's constructor table, Enum.
  var NAMESPACE_KINDS = { lib: 1, execlib: 1, dtype: 1, enums: 1 };

  /// Every name the walker declared anywhere in the file - locals, parameters,
  /// loop variables, at any depth. Deliberately not "in scope right here": the
  /// walker is forgiving by design, and a name it declared *somewhere* is
  /// reason enough to say nothing about it.
  function declaredAnywhere(root) {
    var out = Object.create(null);
    var stack = [root];
    while (stack.length) {
      var scope = stack.pop();
      for (var name in scope.vars) { out[name] = 1; }
      for (var i = 0; i < scope.children.length; i++) { stack.push(scope.children[i]); }
    }
    return out;
  }

  /// One pass for everything the file says about its own names.
  function survey(analysis) {
    var code = analysis.code;
    var T = Lex.T;
    var out = {
      assigned: Object.create(null),   // a global this file defines
      guarded: Object.create(null),    // a name this file tests before using
      strings: Object.create(null),    // a name that appears as a string
      members: Object.create(null),    // "string.trim", which this file adds
      aliases: Object.create(null),    // a local bound to getgenv()/getrenv()
      unsafe: false                    // setfenv/getfenv: nothing is knowable
    };

    for (var i = 0; i < code.length; i++) {
      var tok = code[i];
      var next = code[i + 1];
      var prev = code[i - 1];

      if (tok.t === T.STRING) {
        // "Runner" makes `Runner` reachable through getgenv()["Runner"], and a
        // name the file writes down at all is a name it knows about.
        var text = tok.v.replace(/^[`'"]+/, "").replace(/[`'"]+$/, "");
        if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(text)) { out.strings[text] = 1; }
        continue;
      }
      if (tok.t !== T.NAME) { continue; }

      if (tok.v === "setfenv" || tok.v === "getfenv") { out.unsafe = true; }

      var member = prev && prev.t === T.OP && (prev.v === "." || prev.v === ":");
      var assigns = next && next.t === T.OP && next.v === "=";

      if (!member) {
        // `NAME = …` and `NAME, other = …`. Recorded wherever it appears, not
        // only at a statement start: a table key recorded as a global costs
        // nothing but silence, and a missed one costs a false positive.
        if (assigns || (next && next.t === T.OP && next.v === "," &&
                        analysis.startsStatement(i))) {
          out.assigned[tok.v] = 1;
        }
        // `function NAME(`, and `function NAME.f(` - which needs NAME to exist
        // already, but staying quiet is the conservative direction.
        if (prev && prev.t === T.KEYWORD && prev.v === "function") {
          out.assigned[tok.v] = 1;
        }
        // `local e = getgenv()`
        if (ENV_CALLS[tok.v] && prev && prev.t === T.OP && prev.v === "=") {
          var target = code[i - 2];
          var declare = code[i - 3];
          if (target && target.t === T.NAME && declare && declare.t === T.KEYWORD &&
              declare.v === "local") {
            out.aliases[target.v] = 1;
          }
        }
        // Guards. Any mention in a position that tests the name, anywhere in
        // the file, is enough - this is the rule that makes the whole
        // executor-detection idiom silent.
        if (prev && (GUARD_BEFORE[prev.v] || (prev.t === T.OP && prev.v === "#"))) {
          out.guarded[tok.v] = 1;
        }
        if (next && GUARD_AFTER[next.v]) { out.guarded[tok.v] = 1; }
        if (prev && prev.t === T.OP && prev.v === "(" && code[i - 2] &&
            TYPE_CALLS[code[i - 2].v]) {
          out.guarded[tok.v] = 1;
        }
        continue;
      }

      // A member, on the left of an assignment: `getgenv().Foo = 1` defines a
      // global, `string.trim = f` extends a library.
      if (assigns) {
        var head = code[analysis.prefixStart(i)];
        if (head && head.t === T.NAME) {
          if (ENV_TABLES[head.v] || out.aliases[head.v] || ENV_CALLS[head.v]) {
            out.assigned[tok.v] = 1;
          }
          out.members[head.v + "." + tok.v] = 1;
        }
      }
    }
    return out;
  }

  /// Is this name being used in a way that needs it to exist? A bare read is
  /// not: `if x then`, `local a = x` and `f(x)` are all legal against a nil
  /// global, and every executor-detection idiom is built out of exactly those.
  function isUsed(code, i) {
    var next = code[i + 1];
    if (!next) { return false; }
    if (next.t === Lex.T.STRING) { return true; }          // f"literal"
    if (next.t !== Lex.T.OP) { return false; }
    return next.v === "(" || next.v === "{" || next.v === "." ||
           next.v === ":" || next.v === "[";
  }

  /// The two checks, over one analysis. Offsets, not positions: the page turns
  /// them into positions with the model, and jsc has no model.
  function namesIn(analysis, resolver, text) {
    var out = [];
    if (!analysis || !resolver || !resolver.ready()) { return out; }

    var flags = directives(text);
    if (flags.nocheck || flags.nolint.all) { return out; }

    var facts = survey(analysis);
    if (facts.unsafe) { return out; }

    var declared = declaredAnywhere(analysis.root);
    var code = analysis.code;
    var T = Lex.T;

    for (var i = 0; i < code.length; i++) {
      var tok = code[i];
      if (tok.t !== T.NAME) { continue; }
      var prev = code[i - 1];
      var afterSeparator = prev && prev.t === T.OP && (prev.v === "." || prev.v === ":");

      // -------------------------------------------------- an unknown global
      if (!afterSeparator) {
        if (flags.nolint.UnknownGlobal) { continue; }
        if (!isUsed(code, i)) { continue; }
        if (declared[tok.v] || facts.assigned[tok.v] || facts.guarded[tok.v] ||
            facts.strings[tok.v] || facts.aliases[tok.v]) { continue; }
        if (PRIVATE_PREFIX.test(tok.v)) { continue; }
        if (resolver.isKnownGlobal(tok.v)) { continue; }
        out.push({ start: tok.s, end: tok.e,
                   message: "Unknown global '" + tok.v + "'" });
        continue;
      }

      // -------------------------------------------------- an unknown member
      if (flags.nolint.UnknownMember) { continue; }
      // Only a one-step chain off a bare name: `a.b.c` says nothing about what
      // `a.b` was, and `("x"):rep` has no name at its head at all.
      if (analysis.prefixStart(i) !== i - 2) { continue; }
      var owner = code[i - 2];
      if (!owner || owner.t !== T.NAME) { continue; }
      if (declared[owner.v]) { continue; }                        // shadowed
      if (facts.members[owner.v + "." + tok.v]) { continue; }     // the file adds it
      var type = resolver.globalType(owner.v);
      if (!type || !NAMESPACE_KINDS[type.k]) { continue; }
      if (resolver.hasMember(type, tok.v)) { continue; }
      out.push({ start: tok.s, end: tok.e,
                 message: owner.v + " has no member '" + tok.v + "'" });
    }

    return out;
  }

  // ------------------------------------------------------------------ export

  global.LuauDiagnostics = {
    toMarkers: toMarkers,
    directives: directives,
    namesIn: namesIn,
    messagesAt: messagesAt,
    install: install,
    watch: watch,
    touch: touch,
    forget: forget,
    receive: receive,
    setEnabled: setEnabled,
    setNames: setNames,
    DEBOUNCE_MS: DEBOUNCE_MS
  };

})(typeof window !== "undefined" ? window : globalThis);
