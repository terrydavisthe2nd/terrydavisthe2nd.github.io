//
//  luau-lexer.js
//  NexaGUI — the editor's reading of Luau.
//
//  Monarch colours the text; this is what understands it. One pass produces
//  tokens, a scope tree with an inferred type for every local, and the small
//  facts the editor's providers need: what is under the cursor, where the
//  blocks are, whether the file is short of an `end`. Completion, hover,
//  signature help, folding and the symbol list are all built on it.
//
//  It is deliberately not a parser. A parser has to be right about everything
//  to be useful at all, and a file being edited is wrong by definition — half
//  a statement, an unclosed block, a name that is still being typed. This
//  walks tokens and takes what it can, so an unfinished line costs at most the
//  type of the value on it rather than the whole file's analysis.
//
//  No DOM, no Monaco: it runs under `jsc` for the tests in tests/gui.
//

(function (global) {
  "use strict";

  // ------------------------------------------------------------------ tokens

  var T = {
    NAME: 1,
    KEYWORD: 2,
    NUMBER: 3,
    STRING: 4,
    COMMENT: 5,
    OP: 6
  };

  var KEYWORDS = {
    "and": 1, "break": 1, "do": 1, "else": 1, "elseif": 1, "end": 1,
    "false": 1, "for": 1, "function": 1, "if": 1, "in": 1, "local": 1,
    "nil": 1, "not": 1, "or": 1, "repeat": 1, "return": 1, "then": 1,
    "true": 1, "until": 1, "while": 1, "continue": 1
  };

  // Longest first: `...` must beat `..`, `..=` must beat `..`, `::` must beat `:`.
  var OPERATORS = [
    "...", "..=", "//=", "==", "~=", "<=", ">=", "::", "..", "->",
    "+=", "-=", "*=", "/=", "%=", "^=", "//",
    "+", "-", "*", "/", "%", "^", "#", "<", ">", "=", "(", ")", "{", "}",
    "[", "]", ";", ":", ",", ".", "?", "|", "&", "@"
  ];

  function isDigit(c) { return c >= 48 && c <= 57; }
  function isHex(c) {
    return (c >= 48 && c <= 57) || (c >= 97 && c <= 102) || (c >= 65 && c <= 70);
  }
  function isAlpha(c) {
    return (c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c === 95;
  }
  function isAlnum(c) {
    return (c >= 97 && c <= 122) || (c >= 65 && c <= 90) || c === 95 ||
           (c >= 48 && c <= 57);
  }

  /// How many `=` sit between the two brackets of a long bracket at `i`, or -1
  /// if this is not one. `[[` is level 0, `[==[` is level 2.
  function longBracketLevel(src, i) {
    if (src.charCodeAt(i) !== 91 /* [ */) { return -1; }
    var j = i + 1;
    while (src.charCodeAt(j) === 61 /* = */) { j++; }
    return src.charCodeAt(j) === 91 ? j - i - 1 : -1;
  }

  /// The offset just past a long bracket's closing `]==]`, or the end of the
  /// source when it never closes — an unterminated long string runs to the end
  /// of the file, which is exactly what Luau does with it.
  function longBracketEnd(src, from, level) {
    var close = "]" + new Array(level + 1).join("=") + "]";
    var at = src.indexOf(close, from);
    return at < 0 ? src.length : at + close.length;
  }

  /// Every token in the source, comments and strings included.
  ///
  /// Interpolated strings are taken apart rather than swallowed whole: the
  /// literal pieces come back as STRING and the `{ ... }` holes are lexed as
  /// ordinary code, so completion works inside `` `hello {player.|}` ``.
  function tokenize(src) {
    var tokens = [];
    var n = src.length;
    var i = 0;
    // One entry per open interpolated string, each holding the depth of plain
    // `{` braces nested inside its current hole. `}` closes the hole only at
    // depth 0.
    var interp = [];

    function push(type, start, end) {
      tokens.push({ t: type, v: src.slice(start, end), s: start, e: end });
    }

    /// Scans the literal part of an interpolated string from `at`, which sits
    /// just after a backtick or a `}`. Returns the offset to carry on from.
    function interpBody(at) {
      var start = at;
      while (at < n) {
        var c = src.charCodeAt(at);
        if (c === 92 /* \ */) { at += 2; continue; }
        if (c === 96 /* ` */) {                       // the string ends here
          push(T.STRING, start, at + 1);
          interp.pop();
          return at + 1;
        }
        if (c === 123 /* { */) {                      // a hole opens
          push(T.STRING, start, at);
          push(T.OP, at, at + 1);
          return at + 1;
        }
        if (c === 10 /* \n */) { break; }             // unterminated
        at++;
      }
      push(T.STRING, start, at);
      interp.pop();
      return at;
    }

    while (i < n) {
      var c = src.charCodeAt(i);

      if (c === 32 || c === 9 || c === 13 || c === 10) { i++; continue; }

      // Comments, both kinds. `--!strict` is a directive and is tokenised as a
      // comment; the grammar colours it differently.
      if (c === 45 /* - */ && src.charCodeAt(i + 1) === 45) {
        var level = longBracketLevel(src, i + 2);
        if (level >= 0) {
          var stop = longBracketEnd(src, i + 2, level);
          push(T.COMMENT, i, stop);
          i = stop;
          continue;
        }
        var eol = src.indexOf("\n", i);
        if (eol < 0) { eol = n; }
        push(T.COMMENT, i, eol);
        i = eol;
        continue;
      }

      // Long strings.
      if (c === 91 /* [ */) {
        var slevel = longBracketLevel(src, i);
        if (slevel >= 0) {
          var send = longBracketEnd(src, i + slevel + 2, slevel);
          push(T.STRING, i, send);
          i = send;
          continue;
        }
      }

      // Short strings. An unterminated one stops at the end of its line: a
      // stray quote should cost one line, not colour the rest of the file.
      if (c === 34 /* " */ || c === 39 /* ' */) {
        var quote = c;
        var j = i + 1;
        while (j < n) {
          var d = src.charCodeAt(j);
          if (d === 92) { j += 2; continue; }
          if (d === quote) { j++; break; }
          if (d === 10) { break; }
          j++;
        }
        push(T.STRING, i, j);
        i = j;
        continue;
      }

      if (c === 96 /* ` */) {
        interp.push(0);
        i = interpBody(i + 1);
        continue;
      }

      // Numbers, Luau-flavoured: hex, binary, and `_` as a group separator.
      if (isDigit(c) || (c === 46 /* . */ && isDigit(src.charCodeAt(i + 1)))) {
        var k = i;
        if (c === 48 && (src.charCodeAt(i + 1) === 120 || src.charCodeAt(i + 1) === 88)) {
          k = i + 2;
          while (k < n && (isHex(src.charCodeAt(k)) || src.charCodeAt(k) === 95)) { k++; }
        } else if (c === 48 && (src.charCodeAt(i + 1) === 98 || src.charCodeAt(i + 1) === 66)) {
          k = i + 2;
          while (k < n) {
            var b = src.charCodeAt(k);
            if (b !== 48 && b !== 49 && b !== 95) { break; }
            k++;
          }
        } else {
          var seenDot = false, seenExp = false;
          while (k < n) {
            var e = src.charCodeAt(k);
            if (isDigit(e) || e === 95) { k++; continue; }
            if (e === 46 && !seenDot && !seenExp) { seenDot = true; k++; continue; }
            if ((e === 101 || e === 69) && !seenExp) {
              seenExp = true;
              k++;
              var sign = src.charCodeAt(k);
              if (sign === 43 || sign === 45) { k++; }
              continue;
            }
            break;
          }
        }
        push(T.NUMBER, i, k);
        i = k;
        continue;
      }

      if (isAlpha(c)) {
        var m = i + 1;
        while (m < n && isAlnum(src.charCodeAt(m))) { m++; }
        var word = src.slice(i, m);
        push(KEYWORDS[word] ? T.KEYWORD : T.NAME, i, m);
        i = m;
        continue;
      }

      // Braces inside an interpolated string's hole: the one that matches the
      // hole returns to the string, the rest are ordinary table braces.
      if (interp.length) {
        if (c === 123 /* { */) {
          interp[interp.length - 1]++;
        } else if (c === 125 /* } */) {
          if (interp[interp.length - 1] === 0) {
            push(T.OP, i, i + 1);
            i = interpBody(i + 1);
            continue;
          }
          interp[interp.length - 1]--;
        }
      }

      var matched = null;
      for (var o = 0; o < OPERATORS.length; o++) {
        var op = OPERATORS[o];
        if (src.startsWith(op, i)) { matched = op; break; }
      }
      if (matched) {
        push(T.OP, i, i + matched.length);
        i += matched.length;
        continue;
      }

      // Anything else is a character Luau has no use for. Emit it as an
      // operator so offsets stay exact and move on.
      push(T.OP, i, i + 1);
      i++;
    }

    return tokens;
  }

  // ------------------------------------------------------------------- types
  //
  // A type is a small tagged object. Nothing here is checked — it exists to
  // answer "what can I offer after the dot", so an approximate answer beats no
  // answer, and a wrong one costs a suggestion list rather than a compile.

  var ANY = { k: "any" };

  function cls(name, guess) { return { k: "class", name: name, guess: !!guess }; }
  function datatype(name) { return { k: "datatype", name: name }; }
  function prim(name) { return { k: "prim", name: name }; }
  function arrayOf(of) { return { k: "array", of: of || ANY }; }

  /// The name a type is shown as, in a hover or beside a suggestion.
  function typeLabel(type) {
    if (!type) { return "any"; }
    switch (type.k) {
      case "class":     return type.name;
      case "datatype":  return type.name;
      case "enum":      return "Enum." + type.name;
      case "enumitem":  return "Enum." + type.name;
      case "enums":     return "Enums";
      case "lib":       return type.name;
      case "prim":      return type.name;
      case "array":     return "{" + typeLabel(type.of) + "}";
      case "table":     return "table";
      case "signal":    return "RBXScriptSignal";
      case "func":      return "function";
      case "method":    return "function";
      default:          return "any";
    }
  }

  // ------------------------------------------------------------------ scopes

  function Scope(parent, start) {
    this.parent = parent;
    this.start = start;
    this.end = Infinity;
    this.vars = Object.create(null);
    this.children = [];
    if (parent) { parent.children.push(this); }
  }

  Scope.prototype.declare = function (name, entry) {
    if (!name || name === "_") { return; }
    this.vars[name] = entry;
  };

  /// The innermost scope containing `offset`.
  function scopeAt(root, offset) {
    var found = root;
    var stack = [root];
    while (stack.length) {
      var scope = stack.pop();
      if (offset >= scope.start && offset <= scope.end) {
        if (scope.start >= found.start) { found = scope; }
        for (var i = 0; i < scope.children.length; i++) { stack.push(scope.children[i]); }
      }
    }
    return found;
  }

  /// Everything in view at `offset`, innermost first, each name only once —
  /// an inner `local x` shadows an outer one, and the suggestion list should
  /// say so exactly once.
  function localsAt(root, offset) {
    var out = [];
    var seen = Object.create(null);
    var scope = scopeAt(root, offset);
    var depth = 0;
    while (scope) {
      for (var name in scope.vars) {
        var entry = scope.vars[name];
        if (seen[name] || entry.pos > offset) { continue; }
        seen[name] = 1;
        out.push({
          name: name,
          type: entry.type,
          kind: entry.kind,
          depth: depth,
          params: entry.params,
          doc: entry.doc
        });
      }
      scope = scope.parent;
      depth++;
    }
    return out;
  }

  // ------------------------------------------------------------- the walker
  //
  // One pass over the code tokens. It opens a scope where Luau opens one,
  // declares what a statement declares, and hands every initialiser to the
  // resolver so a local carries a type rather than just a name.

  function Analysis(text, resolver) {
    this.text = text;
    this.resolver = resolver || null;
    this.all = tokenize(text);

    // Comments and strings are needed to answer "where is the cursor", but
    // they are noise to the walker.
    var code = [];
    for (var i = 0; i < this.all.length; i++) {
      if (this.all[i].t !== T.COMMENT) { code.push(this.all[i]); }
    }
    this.code = code;

    this.root = new Scope(null, 0);
    this.root.end = text.length;
    this.symbols = [];
    this.folds = [];
    this.tables = Object.create(null);   // name -> table type, for `M.f = ...`
    this.openBlocks = 0;
    this.directives = [];

    this.walk();
  }

  Analysis.prototype.tokenAt = function (offset) {
    var lo = 0, hi = this.all.length - 1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      var tok = this.all[mid];
      if (offset < tok.s) { hi = mid - 1; }
      else if (offset > tok.e) { lo = mid + 1; }
      else { return tok; }
    }
    return null;
  };

  /// What the cursor is standing in. Completion has no business firing inside
  /// a comment, and inside a string only where the string is an argument that
  /// names something — `GetService("`, `Instance.new("`.
  Analysis.prototype.contextAt = function (offset) {
    for (var i = 0; i < this.all.length; i++) {
      var tok = this.all[i];
      if (tok.s >= offset) { break; }
      if (offset > tok.s && offset <= tok.e) {
        if (tok.t === T.COMMENT) { return { kind: "comment", token: tok }; }
        if (tok.t === T.STRING) {
          // The closing quote is outside the string as far as the cursor is
          // concerned: `"abc"|` is code again.
          if (offset === tok.e && tok.v.length > 1 && isClosed(tok.v)) {
            return { kind: "code" };
          }
          return { kind: "string", token: tok };
        }
      }
    }
    return { kind: "code" };
  };

  function isClosed(text) {
    var first = text.charAt(0);
    if (first === '"' || first === "'") {
      return text.length > 1 && text.charAt(text.length - 1) === first &&
             text.charAt(text.length - 2) !== "\\";
    }
    return true;
  }

  /// Index into `code` of the last token that ends at or before `offset`.
  Analysis.prototype.codeIndexBefore = function (offset) {
    var lo = 0, hi = this.code.length - 1, best = -1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1;
      if (this.code[mid].e <= offset) { best = mid; lo = mid + 1; }
      else { hi = mid - 1; }
    }
    return best;
  };

  var BLOCK_OPENERS = { "do": 1, "then": 1, "repeat": 1, "function": 1 };

  Analysis.prototype.walk = function () {
    var code = this.code;
    var scope = this.root;
    var stack = [];
    var self = this;

    // Loop variables and function parameters are collected while the header is
    // read and declared into the scope the header opens.
    var pending = null;

    function open(start, kind) {
      var fresh = new Scope(scope, start);
      stack.push({ scope: scope, kind: kind, start: start });
      scope = fresh;
      if (pending) {
        for (var i = 0; i < pending.length; i++) {
          scope.declare(pending[i].name, pending[i]);
        }
        pending = null;
      }
      return fresh;
    }

    function close(end) {
      if (!stack.length) { return; }
      var frame = stack.pop();
      scope.end = end;
      if (end - frame.start > 80) {
        self.folds.push({ start: frame.start, end: end, kind: frame.kind });
      }
      scope = frame.scope;
    }

    for (var i = 0; i < code.length; i++) {
      var tok = code[i];

      if (tok.t === T.KEYWORD) {
        var word = tok.v;

        if (word === "local") {
          i = this.readLocal(i, scope);
          continue;
        }
        if (word === "function") {
          var isLocal = i > 0 && code[i - 1].t === T.KEYWORD && code[i - 1].v === "local";
          i = this.readFunction(i, scope, function (params, bodyStart) {
            pending = params;
            open(bodyStart, "function");
          }, isLocal);
          continue;
        }
        if (word === "for") {
          pending = this.readForHeader(i, scope);
          continue;
        }
        if (word === "do" || word === "then" || word === "repeat") {
          open(tok.s, word === "repeat" ? "repeat" : "block");
          continue;
        }
        if (word === "elseif" || word === "else") {
          close(tok.s);
          open(tok.s, "block");
          continue;
        }
        if (word === "end") {
          close(tok.e);
          continue;
        }
        if (word === "until") {
          // A `repeat` body's locals are in view in its `until` expression, so
          // the scope runs to the end of that line rather than to the keyword.
          var eol = this.text.indexOf("\n", tok.e);
          close(eol < 0 ? this.text.length : eol);
          continue;
        }
        continue;
      }

      // `M.field = ...` / `M.a.b = ...` at the start of a statement: the way
      // every module in the wild grows its table.
      if (tok.t === T.NAME && this.startsStatement(i)) {
        var assign = this.readTableAssignment(i, scope);
        if (assign >= 0) { i = assign; continue; }
      }
    }

    while (stack.length) { close(this.text.length); }
    this.openBlocks = this.countOpenBlocks();
  };

  /// True when the token at `i` begins a statement, which is the only place a
  /// bare `name.field = value` can be an assignment rather than an argument.
  Analysis.prototype.startsStatement = function (i) {
    if (i === 0) { return true; }
    var prev = this.code[i - 1];
    if (prev.t === T.KEYWORD) {
      return prev.v === "do" || prev.v === "then" || prev.v === "else" ||
             prev.v === "repeat" || prev.v === "end" || prev.v === "local";
    }
    if (prev.t === T.OP) { return prev.v === ";" || prev.v === ")" || prev.v === "}"; }
    return false;
  };

  /// `local a, b = expr, expr` and `local function f(...)`.
  /// Returns the index of the last token consumed.
  Analysis.prototype.readLocal = function (i, scope) {
    var code = this.code;
    var next = code[i + 1];
    if (!next) { return i; }

    if (next.t === T.KEYWORD && next.v === "function") {
      var nameTok = code[i + 2];
      if (nameTok && nameTok.t === T.NAME) {
        scope.declare(nameTok.v, {
          name: nameTok.v, kind: "function", pos: nameTok.s,
          type: { k: "func" }, params: this.readParams(i + 3).names
        });
        this.symbols.push({
          name: nameTok.v, kind: "function", start: nameTok.s, end: nameTok.e
        });
      }
      // Back to the `local`, so the loop's own step lands on `function` — that
      // keyword is what opens the body's scope, and skipping past it left
      // every parameter and every local inside undeclared.
      return i;
    }

    var names = [];
    var j = i + 1;
    while (j < code.length) {
      var tok = code[j];
      if (tok.t === T.NAME) {
        names.push(tok);
        j++;
        // A type annotation binds tighter than the comma: `local x: number, y`.
        if (code[j] && code[j].t === T.OP && code[j].v === ":") {
          j = this.skipTypeAnnotation(j + 1);
        }
        if (code[j] && code[j].t === T.OP && code[j].v === ",") { j++; continue; }
      }
      break;
    }
    if (!names.length) { return i; }

    var stop = this.statementEnd(j);
    var values = [];
    if (code[j] && code[j].t === T.OP && code[j].v === "=") {
      values = this.splitCommas(j + 1, stop);
    }

    for (var k = 0; k < names.length; k++) {
      var value = values[k];
      var type = value ? this.evalRange(value.from, value.to, scope) : ANY;
      var entry = {
        name: names[k].v,
        kind: type && (type.k === "func" || type.k === "method") ? "function" : "variable",
        pos: code[stop - 1] ? code[stop - 1].e : this.text.length,
        type: type
      };
      if (value && this.isFunctionLiteral(value.from)) {
        entry.kind = "function";
        entry.params = this.readParams(value.from + 1).names;
        this.symbols.push({
          name: entry.name, kind: "function", start: names[k].s, end: names[k].e
        });
      }
      // A table constructor is remembered by name so later `t.field = ...`
      // statements can grow it.
      if (type && type.k === "table") { this.tables[entry.name] = type; }
      scope.declare(entry.name, entry);
    }
    // Stop before the initialiser rather than after it. `local f = function()`
    // has a body, and the walker is what opens its scope and declares its
    // parameters — skipping to the end of the statement skipped all of that.
    return j - 1;
  };

  Analysis.prototype.isFunctionLiteral = function (index) {
    var tok = this.code[index];
    return !!(tok && tok.t === T.KEYWORD && tok.v === "function");
  };

  /// `function name.a.b:c(params)` and `function(params)`. Calls `openBody`
  /// with the parameters and the offset the body starts at.
  Analysis.prototype.readFunction = function (i, scope, openBody, isLocal) {
    var code = this.code;
    var j = i + 1;
    var path = [];
    var isMethod = false;

    while (j < code.length && code[j].t === T.NAME) {
      path.push(code[j]);
      j++;
      if (code[j] && code[j].t === T.OP && (code[j].v === "." || code[j].v === ":")) {
        isMethod = code[j].v === ":";
        j++;
        continue;
      }
      break;
    }

    var params = this.readParams(j);
    // A function handed to `:Connect` is a listener, and the event knows what
    // it will be called with. Without this, the `plr` of
    // `PlayerAdded:Connect(function(plr)` would be untyped — which is the one
    // place completion is asked about most.
    if (!path.length && this.resolver) {
      var host = this.enclosingCall(i);
      var bound = host ? this.resolver.parameterTypes(host, params.names.length) : null;
      if (bound) {
        for (var b = 0; b < params.types.length; b++) {
          if (!params.types[b] && bound[b]) { params.types[b] = bound[b]; }
        }
      }
    }
    // Nothing else said what a parameter is, so its name has to. These are the
    // names Roblox's own API uses for these types, so the guess is a good one —
    // and it only ever decides what is offered after a dot.
    for (var g = 0; g < params.names.length; g++) {
      if (!params.types[g] && this.resolver) {
        params.types[g] = this.resolver.typeFromParameterName(params.names[g]);
      }
    }
    var entries = [];
    if (isMethod) {
      var owner = path.length > 1 ? this.tables[path[0].v] : null;
      entries.push({
        name: "self", kind: "variable", pos: code[i].s,
        type: owner || { k: "table", fields: Object.create(null) }
      });
    }
    for (var p = 0; p < params.names.length; p++) {
      entries.push({
        name: params.names[p],
        kind: "parameter",
        pos: code[i].s,
        type: params.types[p] || ANY
      });
    }

    if (path.length) {
      var full = path[0].v;
      for (var q = 1; q < path.length; q++) { full += (isMethod && q === path.length - 1 ? ":" : ".") + path[q].v; }
      this.symbols.push({
        name: full, kind: "function", start: path[0].s, end: path[path.length - 1].e
      });
      // `function M.f()` is a field of M, and worth completing after `M.`.
      if (path.length > 1) {
        var table = this.tables[path[0].v];
        if (table && table.fields) {
          table.fields[path[path.length - 1].v] = {
            type: { k: "func" }, kind: "function", params: params.names,
            method: isMethod
          };
        }
      } else if (!isMethod && !isLocal) {
        // A bare `function f()` is a global, in view for the whole file.
        // `local function f()` is not, and readLocal has already declared it.
        this.root.declare(full, {
          name: full, kind: "function", pos: 0, type: { k: "func" },
          params: params.names
        });
      }
    }

    openBody(entries, code[i].s);
    return params.end;
  };

  /// The parameter list starting at the `(` at `i`. Types come from the
  /// annotation when there is one; everything else is filled in later, by the
  /// caller that knows what the function is being passed to.
  Analysis.prototype.readParams = function (i) {
    var code = this.code;
    var names = [], types = [];
    if (!code[i] || code[i].t !== T.OP || code[i].v !== "(") {
      return { names: names, types: types, end: i };
    }
    var j = i + 1;
    var depth = 1;
    while (j < code.length && depth > 0) {
      var tok = code[j];
      if (tok.t === T.OP && tok.v === "(") { depth++; j++; continue; }
      if (tok.t === T.OP && tok.v === ")") {
        depth--;
        if (depth === 0) { break; }
        j++;
        continue;
      }
      if (depth === 1 && (tok.t === T.NAME || (tok.t === T.OP && tok.v === "..."))) {
        names.push(tok.v);
        types.push(null);
        j++;
        if (code[j] && code[j].t === T.OP && code[j].v === ":") {
          var typeStart = j + 1;
          j = this.skipTypeAnnotation(typeStart);
          types[types.length - 1] = this.typeFromAnnotation(typeStart, j);
        }
        continue;
      }
      j++;
    }
    return { names: names, types: types, end: j };
  };

  /// Walks past a type annotation, which can be as involved as
  /// `: {[string]: (number) -> Instance?}` and must not be mistaken for code.
  Analysis.prototype.skipTypeAnnotation = function (i) {
    var code = this.code;
    var depth = 0;
    var j = i;
    while (j < code.length) {
      var tok = code[j];
      if (tok.t === T.OP) {
        if (tok.v === "{" || tok.v === "(" || tok.v === "[") { depth++; j++; continue; }
        if (tok.v === "}" || tok.v === ")" || tok.v === "]") {
          if (depth === 0) { return j; }
          depth--;
          j++;
          continue;
        }
        if (depth === 0) {
          if (tok.v === "," || tok.v === "=" || tok.v === ";") { return j; }
          if (tok.v === "." || tok.v === "?" || tok.v === "|" || tok.v === "&" ||
              tok.v === "->") { j++; continue; }
          return j;
        }
        j++;
        continue;
      }
      if (tok.t === T.KEYWORD) {
        if (depth === 0 && tok.v !== "nil" && tok.v !== "typeof" && tok.v !== "function") {
          return j;
        }
        j++;
        continue;
      }
      j++;
    }
    return j;
  };

  /// A type written by hand, for the cases worth understanding: a class name,
  /// a datatype, or a primitive. `Player?` is a Player as far as completion is
  /// concerned.
  Analysis.prototype.typeFromAnnotation = function (from, to) {
    var code = this.code;
    if (from >= to) { return null; }
    var tok = code[from];
    if (tok.t !== T.NAME) { return null; }
    if (code[from + 1] && code[from + 1].t === T.OP && code[from + 1].v === "." &&
        code[from + 2] && code[from + 2].t === T.NAME) {
      return this.resolver ? this.resolver.typeFromName(tok.v + "." + code[from + 2].v) : null;
    }
    return this.resolver ? this.resolver.typeFromName(tok.v) : null;
  };

  /// `for i = 1, 10 do` / `for k, v in pairs(t) do`. Returns the entries the
  /// body's scope should open with.
  Analysis.prototype.readForHeader = function (i, scope) {
    var code = this.code;
    var names = [];
    var j = i + 1;
    while (j < code.length && code[j].t === T.NAME) {
      names.push(code[j]);
      j++;
      if (code[j] && code[j].t === T.OP && code[j].v === ":") { j = this.skipTypeAnnotation(j + 1); }
      if (code[j] && code[j].t === T.OP && code[j].v === ",") { j++; continue; }
      break;
    }
    if (!names.length) { return null; }

    var entries = [];
    var tok = code[j];

    if (tok && tok.t === T.OP && tok.v === "=") {
      // A numeric for. Every one of its variables is a number.
      for (var a = 0; a < names.length; a++) {
        entries.push({ name: names[a].v, kind: "variable", pos: names[a].s, type: prim("number") });
      }
      return entries;
    }

    if (tok && tok.t === T.KEYWORD && tok.v === "in") {
      var stop = this.findDo(j);
      var iterated = this.evalRange(j + 1, stop, scope);
      var element = this.resolver ? this.resolver.iterationTypes(iterated, names.length) : null;
      for (var b = 0; b < names.length; b++) {
        entries.push({
          name: names[b].v, kind: "variable", pos: names[b].s,
          type: (element && element[b]) || ANY
        });
      }
      return entries;
    }
    return null;
  };

  Analysis.prototype.findDo = function (from) {
    var code = this.code;
    for (var j = from; j < code.length; j++) {
      if (code[j].t === T.KEYWORD && code[j].v === "do") { return j; }
      if (code[j].t === T.KEYWORD && (code[j].v === "end" || code[j].v === "then")) { return j; }
    }
    return code.length;
  };

  /// `M.a.b = value` at the start of a statement. Returns the last index
  /// consumed, or -1 when this was not an assignment after all.
  Analysis.prototype.readTableAssignment = function (i, scope) {
    var code = this.code;
    var base = code[i];
    var path = [];
    var j = i + 1;
    while (code[j] && code[j].t === T.OP && code[j].v === "." &&
           code[j + 1] && code[j + 1].t === T.NAME) {
      path.push(code[j + 1]);
      j += 2;
    }
    if (!path.length) { return -1; }
    if (!code[j] || code[j].t !== T.OP || code[j].v !== "=") { return -1; }
    // `==` is a comparison; the tokenizer already split it, so a following `=`
    // would have been part of that token.
    var table = this.tables[base.v];
    if (!table || !table.fields) { return -1; }

    var stop = this.statementEnd(j + 1);
    var type = this.evalRange(j + 1, stop, scope);
    table.fields[path[path.length - 1].v] = {
      type: type,
      kind: type && type.k === "func" ? "function" : "field",
      params: this.isFunctionLiteral(j + 1) ? this.readParams(j + 2).names : undefined
    };
    if (type && type.k === "func") {
      this.symbols.push({
        name: base.v + "." + path[path.length - 1].v, kind: "function",
        start: base.s, end: path[path.length - 1].e
      });
    }
    // As in readLocal: leave the value for the walker, which is what opens the
    // scope of `M.update = function(dt)`.
    return j;
  };

  /// True when a token could be the last of an expression, and when one could
  /// be the first of a statement. A line break between the two is where one
  /// statement ends and the next begins — Lua writes no semicolon, so this is
  /// the only signal there is.
  function canEndExpression(tok) {
    if (tok.t === T.NAME || tok.t === T.NUMBER || tok.t === T.STRING) { return true; }
    if (tok.t === T.KEYWORD) {
      return tok.v === "end" || tok.v === "true" || tok.v === "false" || tok.v === "nil";
    }
    if (tok.t === T.OP) {
      return tok.v === ")" || tok.v === "]" || tok.v === "}" || tok.v === "...";
    }
    return false;
  }

  var STATEMENT_STARTERS = {
    "local": 1, "if": 1, "for": 1, "while": 1, "repeat": 1, "return": 1,
    "do": 1, "function": 1, "break": 1, "continue": 1, "end": 1, "until": 1,
    "else": 1, "elseif": 1
  };

  function canStartStatement(tok) {
    if (tok.t === T.NAME) { return true; }
    return tok.t === T.KEYWORD && !!STATEMENT_STARTERS[tok.v];
  }

  Analysis.prototype.newlineBetween = function (a, b) {
    return this.text.lastIndexOf("\n", b.s) >= a.e;
  };

  /// Where the statement starting at `from` ends: the first token at bracket
  /// depth zero that can only begin a new one.
  Analysis.prototype.statementEnd = function (from) {
    var code = this.code;
    var depth = 0;
    var blocks = 0;
    for (var j = from; j < code.length; j++) {
      var tok = code[j];
      if (depth === 0 && blocks === 0 && j > from &&
          canStartStatement(tok) && canEndExpression(code[j - 1]) &&
          this.newlineBetween(code[j - 1], tok)) {
        return j;
      }
      if (tok.t === T.OP) {
        if (tok.v === "(" || tok.v === "{" || tok.v === "[") { depth++; continue; }
        if (tok.v === ")" || tok.v === "}" || tok.v === "]") {
          if (depth === 0) { return j; }
          depth--;
          continue;
        }
        if (tok.v === ";" && depth === 0 && blocks === 0) { return j; }
        continue;
      }
      if (tok.t === T.KEYWORD && depth === 0) {
        if (BLOCK_OPENERS[tok.v]) { blocks++; continue; }
        if (tok.v === "end" || tok.v === "until") {
          if (blocks === 0) { return j; }
          blocks--;
          continue;
        }
        if (blocks === 0 && (tok.v === "local" || tok.v === "if" || tok.v === "for" ||
                             tok.v === "while" || tok.v === "return" ||
                             tok.v === "break" || tok.v === "continue")) {
          return j;
        }
      }
    }
    return code.length;
  };

  /// Splits `a, b, c` into ranges, ignoring commas inside brackets and inside
  /// a function body.
  Analysis.prototype.splitCommas = function (from, to) {
    var code = this.code;
    var parts = [];
    var depth = 0, blocks = 0, start = from;
    for (var j = from; j < to; j++) {
      var tok = code[j];
      if (tok.t === T.OP) {
        if (tok.v === "(" || tok.v === "{" || tok.v === "[") { depth++; continue; }
        if (tok.v === ")" || tok.v === "}" || tok.v === "]") { depth--; continue; }
        if (tok.v === "," && depth === 0 && blocks === 0) {
          parts.push({ from: start, to: j });
          start = j + 1;
        }
        continue;
      }
      if (tok.t === T.KEYWORD) {
        if (BLOCK_OPENERS[tok.v]) { blocks++; }
        else if (tok.v === "end" || tok.v === "until") { blocks--; }
      }
    }
    if (start < to) { parts.push({ from: start, to: to }); }
    return parts;
  };

  // -------------------------------------------------------------- evaluation

  /// The type of the expression in `[from, to)`. Everything hard is handed to
  /// the resolver, which is the only part that knows what a Roblox class is.
  Analysis.prototype.evalRange = function (from, to, scope) {
    if (!this.resolver || from >= to) { return ANY; }
    var code = this.code;

    // A binary operator at depth zero decides the type on its own.
    var depth = 0, blocks = 0;
    for (var j = from; j < to; j++) {
      var tok = code[j];
      if (tok.t === T.OP) {
        if (tok.v === "(" || tok.v === "{" || tok.v === "[") { depth++; continue; }
        if (tok.v === ")" || tok.v === "}" || tok.v === "]") { depth--; continue; }
        if (depth !== 0 || blocks !== 0) { continue; }
        if (tok.v === "..") { return prim("string"); }
        if (tok.v === "==" || tok.v === "~=" || tok.v === "<" || tok.v === ">" ||
            tok.v === "<=" || tok.v === ">=") { return prim("boolean"); }
        continue;
      }
      if (tok.t === T.KEYWORD) {
        if (BLOCK_OPENERS[tok.v]) { blocks++; continue; }
        if (tok.v === "end" || tok.v === "until") { blocks--; continue; }
        if (blocks !== 0 || depth !== 0) { continue; }
        // `a or b` is usually a default: the interesting type is the left one,
        // falling back to the right when the left says nothing.
        if (tok.v === "or") {
          var left = this.evalChain(from, j, scope);
          if (left && left.k !== "any") { return left; }
          return this.evalChain(j + 1, to, scope);
        }
        if (tok.v === "and") { return this.evalChain(j + 1, to, scope); }
      }
    }
    return this.evalChain(from, to, scope);
  };

  /// A prefix expression: a primary followed by any run of `.name`, `:name()`,
  /// `(args)` and `[index]`.
  Analysis.prototype.evalChain = function (from, to, scope) {
    var code = this.code;
    var R = this.resolver;
    if (!R || from >= to) { return ANY; }

    var j = from;
    var tok = code[j];
    var type = ANY;

    if (tok.t === T.OP && (tok.v === "#" || tok.v === "-")) {
      return tok.v === "#" ? prim("number") : prim("number");
    }
    if (tok.t === T.KEYWORD && tok.v === "not") { return prim("boolean"); }
    if (tok.t === T.KEYWORD && tok.v === "function") { return { k: "func" }; }
    if (tok.t === T.KEYWORD && (tok.v === "true" || tok.v === "false")) { return prim("boolean"); }
    if (tok.t === T.KEYWORD && tok.v === "nil") { return ANY; }
    if (tok.t === T.NUMBER) { return prim("number"); }
    if (tok.t === T.STRING) {
      if (j + 1 >= to) { return prim("string"); }
      type = prim("string");
      j++;
    } else if (tok.t === T.OP && tok.v === "{") {
      var closeAt = this.matchBracket(j, to);
      type = this.readTableConstructor(j, closeAt, scope);
      j = closeAt + 1;
      if (j >= to) { return type; }
    } else if (tok.t === T.OP && tok.v === "(") {
      var inner = this.matchBracket(j, to);
      type = this.evalRange(j + 1, inner, scope);
      j = inner + 1;
    } else if (tok.t === T.NAME) {
      var local = this.lookup(scope, tok.v, tok.s);
      // A handful of calls are transparent: they say nothing about the type
      // themselves and hand back something built from their first argument.
      // `ipairs(t)` is the one that matters — without it the `v` of every
      // `for _, v in ipairs(parts)` would be untyped.
      var rule = local ? null : R.argumentCall(tok.v);
      if (rule && code[j + 1] && code[j + 1].t === T.OP && code[j + 1].v === "(") {
        var argEnd = this.matchBracket(j + 1, to);
        var first = this.splitCommas(j + 2, argEnd)[0];
        var inner = first ? this.evalRange(first.from, first.to, scope) : ANY;
        type = rule === "iter" ? { k: "iter", of: inner } : inner;
        j = argEnd + 1;
      } else {
        type = local ? local.type : R.globalType(tok.v);
        j++;
      }
    } else {
      return ANY;
    }

    while (j < to) {
      var next = code[j];
      if (next.t === T.OP && next.v === "." && code[j + 1] && code[j + 1].t === T.NAME) {
        type = R.memberType(type, code[j + 1].v);
        j += 2;
        continue;
      }
      if (next.t === T.OP && next.v === ":" && code[j + 1] && code[j + 1].t === T.NAME) {
        var method = code[j + 1].v;
        var argsFrom = j + 2;
        var argsTo = argsFrom;
        if (code[argsFrom] && code[argsFrom].t === T.OP && code[argsFrom].v === "(") {
          argsTo = this.matchBracket(argsFrom, to);
        }
        type = R.callType(type, method, this.literalArgs(argsFrom, argsTo));
        j = argsTo + 1;
        continue;
      }
      if (next.t === T.OP && next.v === "(") {
        var callEnd = this.matchBracket(j, to);
        type = R.plainCallType(type, this.literalArgs(j, callEnd));
        j = callEnd + 1;
        continue;
      }
      if (next.t === T.OP && next.v === "[") {
        var indexEnd = this.matchBracket(j, to);
        type = R.indexType(type, this.literalIndex(j + 1, indexEnd));
        j = indexEnd + 1;
        continue;
      }
      if (next.t === T.STRING || (next.t === T.OP && next.v === "{")) {
        // `f"literal"` and `f{table}` are calls with one argument.
        type = R.plainCallType(type, [next.t === T.STRING ? stringValue(next.v) : null]);
        j = next.t === T.STRING ? j + 1 : this.matchBracket(j, to) + 1;
        continue;
      }
      break;
    }
    return type || ANY;
  };

  /// The string literals in an argument list, which is what the call rules
  /// need: `GetService("Players")` is only useful if "Players" is legible.
  Analysis.prototype.literalArgs = function (from, to) {
    var code = this.code;
    var out = [];
    if (!code[from] || code[from].t !== T.OP || code[from].v !== "(") { return out; }
    var parts = this.splitCommas(from + 1, to);
    for (var i = 0; i < parts.length; i++) {
      var tok = code[parts[i].from];
      out.push(tok && tok.t === T.STRING && parts[i].to - parts[i].from === 1
        ? stringValue(tok.v) : null);
    }
    return out;
  };

  Analysis.prototype.literalIndex = function (from, to) {
    var tok = this.code[from];
    if (!tok || to - from !== 1) { return null; }
    if (tok.t === T.STRING) { return stringValue(tok.v); }
    if (tok.t === T.NUMBER) { return Number(tok.v.replace(/_/g, "")); }
    return null;
  };

  function stringValue(raw) {
    if (!raw) { return null; }
    var first = raw.charAt(0);
    if (first === '"' || first === "'") {
      var body = raw.slice(1);
      if (body.charAt(body.length - 1) === first) { body = body.slice(0, -1); }
      return body;
    }
    return null;
  }

  /// The index of the bracket that closes the one at `from`, or `to`.
  Analysis.prototype.matchBracket = function (from, to) {
    var code = this.code;
    var open = code[from].v;
    var close = open === "(" ? ")" : (open === "{" ? "}" : "]");
    var depth = 0;
    var limit = to === undefined ? code.length : Math.max(to, from + 1);
    for (var j = from; j < code.length; j++) {
      var tok = code[j];
      if (tok.t !== T.OP) { continue; }
      if (tok.v === open) { depth++; continue; }
      if (tok.v === close) {
        depth--;
        if (depth === 0) { return j; }
      }
      if (j > limit && depth === 0) { break; }
    }
    return limit;
  };

  Analysis.prototype.readTableConstructor = function (from, to, scope) {
    var code = this.code;
    var fields = Object.create(null);
    var parts = this.splitCommas(from + 1, to);
    for (var i = 0; i < parts.length; i++) {
      var a = parts[i].from;
      var key = code[a];
      if (!key) { continue; }
      if (key.t === T.NAME && code[a + 1] && code[a + 1].t === T.OP && code[a + 1].v === "=") {
        var type = this.evalRange(a + 2, parts[i].to, scope);
        fields[key.v] = {
          type: type,
          kind: type && type.k === "func" ? "function" : "field",
          params: this.isFunctionLiteral(a + 2) ? this.readParams(a + 3).names : undefined
        };
        continue;
      }
      if (key.t === T.OP && key.v === "[") {
        var closeAt = this.matchBracket(a, parts[i].to);
        var name = this.literalIndex(a + 1, closeAt);
        if (typeof name === "string" && code[closeAt + 1] && code[closeAt + 1].v === "=") {
          fields[name] = { type: this.evalRange(closeAt + 2, parts[i].to, scope), kind: "field" };
        }
      }
    }
    return { k: "table", fields: fields };
  };

  Analysis.prototype.lookup = function (scope, name, offset) {
    var current = scope;
    while (current) {
      var entry = current.vars[name];
      if (entry && entry.pos <= offset) { return entry; }
      current = current.parent;
    }
    return null;
  };

  // ----------------------------------------------------- what the cursor is on

  /// The type of the expression that a trailing `.` or `:` at `offset` hangs
  /// off, with the separator that was typed. Returns null when there is none.
  Analysis.prototype.memberContext = function (offset) {
    var code = this.code;
    var index = this.codeIndexBefore(offset);
    if (index < 0) { return null; }

    // Skip the part-typed member name, if any.
    var tok = code[index];
    if (tok.t === T.NAME && tok.e === offset) { index--; }
    if (index < 0) { return null; }

    var sep = code[index];
    if (sep.t !== T.OP || (sep.v !== "." && sep.v !== ":")) { return null; }

    var end = index;                       // exclusive end of the prefix
    var start = this.prefixStart(index - 1);
    if (start < 0 || start > index - 1) { return null; }

    var scope = scopeAt(this.root, offset);
    return {
      separator: sep.v,
      type: this.evalChain(start, end, scope),
      from: start,
      to: end
    };
  };

  /// Walks back from `end` over a prefix expression — names, dots, and
  /// balanced call or index brackets — and returns where it starts.
  Analysis.prototype.prefixStart = function (end) {
    var code = this.code;
    var j = end;
    var expectValue = true;

    while (j >= 0) {
      var tok = code[j];
      if (expectValue) {
        if (tok.t === T.NAME) { expectValue = false; j--; continue; }
        if (tok.t === T.OP && (tok.v === ")" || tok.v === "]")) {
          j = this.matchBracketBackwards(j);
          if (j < 0) { return j + 1; }
          // Still looking for a value: the callee of the call, or the table
          // being indexed, is what comes next going backwards.
          j--;
          continue;
        }
        if (tok.t === T.STRING) { expectValue = false; j--; continue; }
        return j + 1;
      }
      if (tok.t === T.OP && (tok.v === "." || tok.v === ":")) { expectValue = true; j--; continue; }
      // A name straight after a name is a new statement, not a chain.
      return j + 1;
    }
    return 0;
  };

  Analysis.prototype.matchBracketBackwards = function (from) {
    var code = this.code;
    var close = code[from].v;
    var open = close === ")" ? "(" : (close === "]" ? "[" : "{");
    var depth = 0;
    for (var j = from; j >= 0; j--) {
      var tok = code[j];
      if (tok.t !== T.OP) { continue; }
      if (tok.v === close) { depth++; continue; }
      if (tok.v === open) {
        depth--;
        if (depth === 0) { return j; }
      }
    }
    return -1;
  };

  /// The call the cursor is inside, for parameter hints: the function's
  /// prefix, the method name if it was a `:` call, and which argument the
  /// caret is in.
  Analysis.prototype.callContext = function (offset) {
    var index = this.codeIndexBefore(offset);
    if (index < 0) { return null; }
    return this.callAtIndex(index, offset);
  };

  /// The call whose argument list the token at `index` sits in.
  Analysis.prototype.enclosingCall = function (index) {
    return this.callAtIndex(index - 1, this.code[index] ? this.code[index].s : 0);
  };

  Analysis.prototype.callAtIndex = function (index, offset) {
    var code = this.code;
    if (index < 0) { return null; }

    var depth = 0;
    var argument = 0;
    for (var j = index; j >= 0; j--) {
      var tok = code[j];
      if (tok.t === T.OP) {
        if (tok.v === ")" || tok.v === "}" || tok.v === "]") { depth++; continue; }
        if (tok.v === "(" ) {
          if (depth === 0) { return this.describeCall(j, argument, offset); }
          depth--;
          continue;
        }
        if (tok.v === "{" || tok.v === "[") {
          if (depth === 0) { return null; }
          depth--;
          continue;
        }
        if (tok.v === "," && depth === 0) { argument++; continue; }
        continue;
      }
      // A block keyword at depth zero means the call, if there was one, is
      // long closed.
      if (tok.t === T.KEYWORD && depth === 0 &&
          (tok.v === "do" || tok.v === "then" || tok.v === "end" ||
           tok.v === "local" || tok.v === "return")) {
        return null;
      }
    }
    return null;
  };

  Analysis.prototype.describeCall = function (parenIndex, argument, offset) {
    var code = this.code;
    var nameIndex = parenIndex - 1;
    if (nameIndex < 0 || code[nameIndex].t !== T.NAME) { return null; }

    var separator = null;
    var start = nameIndex;
    if (nameIndex - 1 >= 0 && code[nameIndex - 1].t === T.OP &&
        (code[nameIndex - 1].v === "." || code[nameIndex - 1].v === ":")) {
      separator = code[nameIndex - 1].v;
      start = this.prefixStart(nameIndex - 2);
    }

    var scope = scopeAt(this.root, offset);
    return {
      name: code[nameIndex].v,
      separator: separator,
      owner: separator ? this.evalChain(start, nameIndex - 1, scope) : null,
      local: separator ? null : this.lookup(scope, code[nameIndex].v, offset),
      argument: argument
    };
  };

  /// True when the string at `offset` is the first argument of a call whose
  /// name is one of `names` — `GetService("`, `Instance.new("`, `IsA("`.
  Analysis.prototype.stringCallName = function (offset) {
    var code = this.code;
    var index = this.codeIndexBefore(offset);
    for (var j = index; j >= 0 && j > index - 6; j--) {
      var tok = code[j];
      if (tok.t === T.OP && tok.v === "(" && j - 1 >= 0 && code[j - 1].t === T.NAME) {
        return {
          name: code[j - 1].v,
          owner: (j - 2 >= 0 && code[j - 2].t === T.OP &&
                  (code[j - 2].v === "." || code[j - 2].v === ":"))
            ? this.evalChain(this.prefixStart(j - 3), j - 2, scopeAt(this.root, offset))
            : null
        };
      }
      if (tok.t === T.OP && (tok.v === ")" || tok.v === ";")) { return null; }
    }
    return null;
  };

  /// How many blocks are open at the end of the file. `end` is inserted on
  /// Enter only when the file is actually short of one — a file that already
  /// balances should not grow a stray `end` every time you open a function.
  Analysis.prototype.countOpenBlocks = function () {
    var code = this.code;
    var open = 0;
    for (var i = 0; i < code.length; i++) {
      var tok = code[i];
      if (tok.t !== T.KEYWORD) { continue; }
      if (tok.v === "function") {
        // `function` in a type annotation (`: (a) -> b`) never opens a block,
        // but a bare `function` keyword always does.
        open++;
      } else if (tok.v === "do") {
        open++;
      } else if (tok.v === "then" || tok.v === "repeat") {
        open++;
      } else if (tok.v === "end" || tok.v === "until") {
        open--;
      } else if (tok.v === "elseif" || tok.v === "else") {
        // `elseif ... then` and `else` each close one and open one.
        if (tok.v === "elseif") { open--; }
      }
    }
    return open;
  };

  // ------------------------------------------------------------------ export

  global.LuauLex = {
    T: T,
    KEYWORDS: KEYWORDS,
    tokenize: tokenize,
    analyse: function (text, resolver) { return new Analysis(text, resolver); },
    scopeAt: scopeAt,
    localsAt: localsAt,
    typeLabel: typeLabel,
    ANY: ANY,
    cls: cls,
    datatype: datatype,
    prim: prim,
    arrayOf: arrayOf
  };

})(typeof window !== "undefined" ? window : globalThis);
