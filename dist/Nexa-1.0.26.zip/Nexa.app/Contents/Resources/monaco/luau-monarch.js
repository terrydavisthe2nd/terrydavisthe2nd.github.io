//
//  luau-monarch.js
//  NexaGUI — how Luau is coloured, and how the editor behaves inside it.
//
//  Monarch is a state machine over the text, one line at a time, and that is
//  exactly what colouring should be: fast, incremental, and never wrong about
//  a line because of something a hundred lines further down. The semantic side
//  — what a name *means* — is `luau-lexer.js` and `luau-resolve.js`, and it is
//  used for completion and hover, never for colour.
//
//  What the tokens mean, and what each maps to in a preset (see MonacoTheme in
//  gui/Theme.swift):
//
//      keyword                    control flow, `local`, `and`/`or`/`not`
//      constant.language          true, false, nil
//      variable.language.self     `self` inside a method
//      variable.language.roblox   game, workspace, script, Enum
//      support.type               Vector3, CFrame, Instance, a service name
//      support.function           a Luau builtin: print, pairs, math
//      support.function.executor  a function this executor provides
//      entity.name.function       a function being defined, or one we cannot
//                                 place — yours, in other words
//      variable.property          the `b` of `a.b`
//      type                       a type annotation, and an @attribute
//      comment.directive          `--!strict` and friends
//

(function (global) {
  "use strict";

  /// The grammar. `names` carries the word lists it colours by, so the
  /// language can be re-registered with a longer list once api.js has loaded
  /// without any of this being written twice.
  function grammar(names) {
    return {
      defaultToken: "",
      tokenPostfix: "",
      ignoreCase: false,

      keywords: [
        "and", "break", "do", "else", "elseif", "end", "for", "function",
        "if", "in", "local", "not", "or", "repeat", "return", "then",
        "until", "while", "continue"
      ],
      // Literals, not control flow: they read as values, and they are coloured
      // as values.
      constants: ["true", "false", "nil"],
      typeKeywords: ["type", "export", "typeof"],
      builtinTypes: [
        "any", "number", "string", "boolean", "thread", "never", "unknown",
        "buffer", "vector", "table", "userdata", "nil"
      ],

      executorGlobals: names.executor,
      robloxGlobals: names.roblox,
      robloxTypes: names.types,
      luauGlobals: names.luau,

      brackets: [
        { open: "{", close: "}", token: "delimiter.curly" },
        { open: "[", close: "]", token: "delimiter.square" },
        { open: "(", close: ")", token: "delimiter.parenthesis" }
      ],

      escapes: /\\(?:[abfnrtvz\\"'`\n]|x[0-9A-Fa-f]{2}|z\s*|[0-9]{1,3}|u\{[0-9A-Fa-f]+\})/,

      tokenizer: {
        root: [
          { include: "@whitespace" },

          // `@native`, `@checked`. `@@` is how Monarch spells a literal `@`.
          [/@@[a-zA-Z_]\w*/, "annotation"],

          // `export type Name` / `type Name =`. The lookahead is what keeps
          // the `type(v)` builtin out of it.
          [/(export)(\s+)(type)(\s+)([A-Za-z_]\w*)/,
            ["keyword", "white", "keyword", "white", "type"]],
          [/(type)(\s+)([A-Za-z_]\w*)(?=\s*[=<])/, ["keyword", "white", "type"]],

          // `function foo.bar:baz(` — the whole dotted path is the name.
          [/(function)(\s+)([a-zA-Z_][\w.:]*)/, ["keyword", "white", "entity.name.function"]],
          [/(local)(\s+)(function)(\s+)([a-zA-Z_]\w*)/,
            ["keyword", "white", "keyword", "white", "entity.name.function"]],

          // `::` is a type assertion and has to beat the `:` rules below.
          [/::/, "operator"],

          // `:method(` — only where a call really follows, so `x: number` is
          // left to the annotation rule underneath.
          [/(:)([ \t]*)([a-zA-Z_]\w*)(?=[ \t]*[({"'`])/,
            ["delimiter", "white", "entity.name.method"]],
          // `: Type` in a parameter, a return, or a local.
          [/(:)([ \t]*)([A-Za-z_][\w.]*)/, ["delimiter", "white", "type"]],

          // `Instance.new(`, `math.floor(`, `task.wait(`: a call on a name the
          // engine defines is the engine's, not yours. The name is matched
          // here only when a `.member(` follows, and the member is coloured
          // by the state this enters - Monarch cannot look at one group while
          // colouring another, but it can remember where it came from.
          [/[a-zA-Z_]\w*(?=\.[a-zA-Z_]\w*[ \t]*[({"'`])/, {
            cases: {
              "@robloxTypes": { token: "support.type", next: "@engineMember" },
              "@robloxGlobals": { token: "variable.language.roblox", next: "@engineMember" },
              "@luauGlobals": { token: "support.function", next: "@engineMember" },
              "@executorGlobals": { token: "support.function.executor", next: "@engineMember" },
              "@default": { token: "@rematch", next: "@plainMember" }
            }
          }],

          // `a.b` where b is not being called. Its own colour: a field is not
          // a variable, and without this a field named `wait` or `game` would
          // be painted as the global of that name. `..` is safe — the second
          // dot is not a letter, so concatenation still falls through.
          //
          // The lookahead also refuses a word character, or the regex would
          // back off to a shorter name to satisfy it: `.new(` used to match
          // as `.ne` plus a call named `w`, and `new` was painted in two
          // colours.
          [/(\.)([a-zA-Z_]\w*)(?!\w|[ \t]*[({"'`])/, ["delimiter", "variable.property"]],

          // A bare call: `foo(`, `foo"..."`, `foo{...}`.
          [/[a-zA-Z_]\w*(?=[ \t]*[({"'`])/, {
            cases: {
              "@keywords": "keyword",
              "@constants": "constant.language",
              "@typeKeywords": "keyword",
              "@executorGlobals": "support.function.executor",
              "@robloxTypes": "support.type",
              "@robloxGlobals": "variable.language.roblox",
              "@luauGlobals": "support.function",
              "@default": "entity.name.function"
            }
          }],

          // Everything else that looks like a word.
          [/[a-zA-Z_]\w*/, {
            cases: {
              "self": "variable.language.self",
              "@keywords": "keyword",
              "@constants": "constant.language",
              "@typeKeywords": "keyword",
              "@builtinTypes": "type",
              "@executorGlobals": "support.function.executor",
              "@robloxTypes": "support.type",
              "@robloxGlobals": "variable.language.roblox",
              "@luauGlobals": "support.function",
              "@default": "identifier"
            }
          }],

          // Long strings, with the same bracket level at both ends.
          [/\[([=]*)\[/, { token: "string", next: "@longstring.$1" }],

          [/[{}()\[\]]/, "@brackets"],

          // Numbers, Luau-flavoured: hex, binary, and `_` separators.
          [/0[xX][0-9a-fA-F_]+/, "number.hex"],
          [/0[bB][01_]+/, "number.binary"],
          [/[0-9][0-9_]*\.[0-9_]*([eE][-+]?[0-9]+)?/, "number.float"],
          [/\.[0-9][0-9_]*([eE][-+]?[0-9]+)?/, "number.float"],
          [/[0-9][0-9_]*([eE][-+]?[0-9]+)?/, "number"],

          // Compound assignment first: `..=` must beat `..`, `+=` beat `+`.
          [/(\.\.=|\/\/=|[+\-*\/%^]=|\.\.\.|\.\.|->|==|~=|<=|>=)/, "operator"],
          [/[+\-*\/%^#<>=~|&?]/, "operator"],
          [/[;,.]/, "delimiter"],

          [/`/, { token: "string", next: "@interp" }],
          [/"(?:[^"\\]|\\.)*$/, "string.invalid"],
          [/'(?:[^'\\]|\\.)*$/, "string.invalid"],
          [/"/, { token: "string", next: "@string.\"" }],
          [/'/, { token: "string", next: "@string.'" }]
        ],

        // After `Instance` in `Instance.new(`: the member is the engine's.
        engineMember: [
          [/(\.)([a-zA-Z_]\w*)/, ["delimiter", { token: "support.function", next: "@pop" }]],
          [/./, { token: "@rematch", next: "@pop" }]
        ],

        // After a name of yours in `thing.member(`: the member is yours too.
        // The name itself is re-tokenised by the ordinary word rule.
        plainMember: [
          [/[a-zA-Z_]\w*/, {
            cases: {
              "self": { token: "variable.language.self", next: "@pop" },
              "@keywords": { token: "keyword", next: "@pop" },
              "@default": { token: "identifier", next: "@pop" }
            }
          }],
          [/./, { token: "@rematch", next: "@pop" }]
        ],

        whitespace: [
          [/[ \t\r\n]+/, "white"],
          // `--!strict`, `--!native`, `--!optimize 2`. A directive changes how
          // the file is compiled, so it should not read as a note to a reader.
          [/--!.*$/, "comment.directive"],
          // A long comment. `$1` captures the `=` run so the close must match.
          [/--\[([=]*)\[/, { token: "comment", next: "@longcomment.$1" }],
          [/--.*$/, "comment"]
        ],

        longcomment: [
          [/[^\]]+/, "comment"],
          [/\]([=]*)\]/, {
            cases: { "$1==$S2": { token: "comment", next: "@pop" }, "@default": "comment" }
          }],
          [/./, "comment"]
        ],

        longstring: [
          [/[^\]]+/, "string"],
          [/\]([=]*)\]/, {
            cases: { "$1==$S2": { token: "string", next: "@pop" }, "@default": "string" }
          }],
          [/./, "string"]
        ],

        string: [
          [/[^\\"']+/, "string"],
          [/@escapes/, "string.escape"],
          [/\\./, "string.escape.invalid"],
          [/["']/, {
            cases: { "$#==$S2": { token: "string", next: "@pop" }, "@default": "string" }
          }]
        ],

        // Interpolated strings: `hi {name}`. The braces hold real expressions,
        // so they re-enter the root tokenizer.
        interp: [
          [/[^\\`{]+/, "string"],
          [/@escapes/, "string.escape"],
          [/\{/, { token: "delimiter.bracket", next: "@interpExpr" }],
          [/`/, { token: "string", next: "@pop" }]
        ],

        interpExpr: [
          [/\}/, { token: "delimiter.bracket", next: "@pop" }],
          { include: "@root" }
        ]
      }
    };
  }

  /// Brackets, comments, indentation and the pairs the editor closes for you.
  var configuration = {
    comments: { lineComment: "--", blockComment: ["--[[", "]]"] },
    brackets: [["{", "}"], ["[", "]"], ["(", ")"]],
    colorizedBracketPairs: [["{", "}"], ["[", "]"], ["(", ")"]],
    autoClosingPairs: [
      { open: "{", close: "}" },
      { open: "[", close: "]" },
      { open: "(", close: ")" },
      { open: '"', close: '"', notIn: ["string", "comment"] },
      { open: "'", close: "'", notIn: ["string", "comment"] },
      { open: "`", close: "`", notIn: ["string", "comment"] }
    ],
    surroundingPairs: [
      { open: "{", close: "}" }, { open: "[", close: "]" },
      { open: "(", close: ")" }, { open: '"', close: '"' },
      { open: "'", close: "'" }, { open: "`", close: "`" }
    ],
    wordPattern: /(-?\d*\.\d\w*)|([^\`\~\!\@\#\%\^\&\*\(\)\-\=\+\[\{\]\}\\\|\;\:\'\"\,\.\<\>\/\?\s]+)/g,

    // Indent after a line that opens something and does not close it again.
    //
    // The old pattern only matched a line *ending* in a block keyword, so
    // `function update(dt)` — which ends in `)` — indented nothing, which is
    // the single most common line in a Luau file. Both halves are anchored at
    // the end of the line, so `if ready then return end` correctly indents
    // nothing at all.
    indentationRules: {
      increaseIndentPattern:
        /^((?!--).)*(\b(then|do|else|repeat)\b|\bfunction\b\s*[A-Za-z_0-9.:]*\s*\([^)]*\)|=\s*\bfunction\b\s*\([^)]*\)|[\{\(\[])\s*$/,
      decreaseIndentPattern: /^\s*((\b(elseif|else|end|until)\b)|[\}\)\]])/
    },

    folding: {
      markers: {
        start: /^\s*--\s*#?region\b/,
        end: /^\s*--\s*#?endregion\b/
      }
    },

    onEnterRules: [
      {
        // Opening a block and closing it on the same line puts the caret on
        // its own indented line, the way it works for braces elsewhere.
        beforeText: /^\s*((\b(function|if|for|while)\b).*(\b(then|do)\b)?|.*\bfunction\b.*\(.*\))\s*$/,
        afterText: /^\s*\b(end|until)\b/,
        action: { indentAction: 2 }   // IndentAction.IndentOutdent
      },
      {
        // Carry a long comment's body down to the next line.
        beforeText: /^\s*--\[\[/,
        afterText: /^\s*\]\]/,
        action: { indentAction: 2 }
      }
    ]
  };

  /// The word lists the grammar colours by. `globals.js` is loaded before the
  /// editor is built and carries the executor's surface; `api.js` arrives
  /// later and adds every class, service and datatype name.
  function wordLists(globalsTable, api) {
    var G = globalsTable || { executor: [], libraries: {}, roblox: [], luau: [], services: [] };
    var executor = G.executor.concat(Object.keys(G.libraries || {}));
    var types = (G.services || []).slice();
    var roblox = [];

    // Three kinds, and each reads differently in the editor:
    //   `game`, `workspace`, `script`  — values you can hold
    //   `Vector3`, `Instance`, a service name — types you construct from
    //   `print`, `warn`, `typeof`, `wait` — functions you call
    // Splitting on capitalisation alone put every one of those functions in
    // with the values.
    var VALUES = { game: 1, workspace: 1, script: 1, shared: 1, _G: 1, plugin: 1 };
    var functions = [];
    for (var i = 0; i < (G.roblox || []).length; i++) {
      var name = G.roblox[i];
      if (VALUES[name]) { roblox.push(name); }
      else if (name.charAt(0) === name.charAt(0).toUpperCase()) { types.push(name); }
      else { functions.push(name); }
    }
    roblox.push("Enum");

    if (api) {
      for (var dt in api.datatypes) { types.push(dt); }
      for (var cls in api.classes) {
        if ((api.classes[cls].tags || []).indexOf("Service") >= 0) { types.push(cls); }
      }
    }

    return {
      executor: unique(executor),
      roblox: unique(roblox),
      types: unique(types),
      luau: unique((G.luau || []).concat(functions, api ? namesOfGlobals(api) : []))
    };
  }

  /// Every name Luau or the engine puts in scope on its own: the global
  /// functions, and the library tables they hang off.
  function namesOfGlobals(api) {
    var out = [];
    var g = api.globals || { props: [], funcs: [] };
    for (var i = 0; i < g.funcs.length; i++) { out.push(g.funcs[i][0]); }
    for (var lib in api.libraries) { out.push(lib); }
    return out;
  }

  function unique(list) {
    var seen = Object.create(null);
    var out = [];
    for (var i = 0; i < list.length; i++) {
      var name = list[i];
      if (!name || seen[name]) { continue; }
      seen[name] = 1;
      out.push(name);
    }
    return out;
  }

  global.LuauGrammar = {
    grammar: grammar,
    configuration: configuration,
    wordLists: wordLists
  };

})(typeof window !== "undefined" ? window : globalThis);
