//
//  luau-resolve.js
//  NexaGUI — everything the editor knows about Roblox and about this executor.
//
//  `luau-lexer.js` works out the shape of the file; this answers the questions
//  it cannot: what a bare name is, what a member of a class is, what a call
//  gives back, and what should be offered after a dot. It reads three
//  generated tables and one written one:
//
//    api.js            classes, members, enums, datatypes, libraries, globals
//                      (tools/gen-api.py, from the Roblox API Reference at
//                      robloxapi.github.io/ref and Roblox's full API dump)
//    api-docs.js       the reference's full description of each of those,
//                      loaded after api.js and read by the hover
//    globals.js        the executor's surface, with argument names scraped
//                      out of src/lua (tools/gen-globals.py)
//    executor-docs.js  a signature and a sentence for the executor functions
//                      worth explaining, written by hand
//
//  It never touches the DOM or Monaco, so the tests in tests/gui can drive it
//  under `jsc`.
//

(function (global) {
  "use strict";

  var Lex = global.LuauLex;
  var ANY = { k: "any" };

  function cls(name, guess) { return { k: "class", name: name, guess: !!guess }; }
  function prim(name) { return { k: "prim", name: name }; }

  // Instance methods whose return type the dump cannot express, because it
  // depends on the argument rather than on the method. These are the calls
  // every Roblox script is built out of, so getting them right is most of what
  // makes completion feel like it understands the file.
  var BY_ARGUMENT = {
    GetService: "class", FindService: "class",
    FindFirstChildOfClass: "class", FindFirstChildWhichIsA: "class",
    FindFirstAncestorOfClass: "class", FindFirstAncestorWhichIsA: "class",
    // These name a child rather than a class, but a child is very often named
    // after its class — `Character:WaitForChild("Humanoid")`. A guess, and
    // marked as one, but a far better answer than a bare Instance.
    FindFirstChild: "guess", WaitForChild: "guess", FindFirstAncestor: "guess",
    FindFirstDescendant: "guess"
  };

  // Calls that give back a list of something more specific than Instance.
  var ARRAY_RETURNS = {
    GetPlayers: "Player", GetTouchingParts: "BasePart", GetConnectedParts: "BasePart",
    GetJoints: "Instance", GetPartsInPart: "BasePart", GetPartBoundsInBox: "BasePart",
    GetPartBoundsInRadius: "BasePart", GetHumanoidDescriptionFromUserId: "HumanoidDescription",
    GetAccessories: "Accessory", GetPlayingAnimationTracks: "AnimationTrack",
    GetChildren: "Instance", GetDescendants: "Instance"
  };

  // Calls that hand back what they were given.
  var IDENTITY_CALLS = { Clone: 1, cloneref: 1, clonereference: 1, clonefunction: 1 };

  // Bare calls whose type comes from their first argument rather than from a
  // signature. `iter` marks the two that produce a loop rather than a value.
  var ARGUMENT_CALLS = {
    ipairs: "iter", pairs: "iter", next: "iter",
    cloneref: "self", clonereference: "self", tostring: null
  };

  var STRING_METHOD_OWNER = "string";

  // ------------------------------------------------------------------ index

  function Resolver() {
    this.api = global.NEXA_API || null;
    this.exec = global.NEXA_GLOBALS || null;
    this.docs = global.NEXA_EXEC_DOCS || {};
    this.memberCache = Object.create(null);
    this.memberSets = Object.create(null);
    this.flatCache = Object.create(null);
    this.execNames = Object.create(null);
    this.execLibs = Object.create(null);
    this.serviceNames = [];

    if (this.exec) {
      for (var i = 0; i < this.exec.executor.length; i++) {
        this.execNames[this.exec.executor[i]] = 1;
      }
      for (var lib in this.exec.libraries) { this.execLibs[lib] = this.exec.libraries[lib]; }
    }
    if (this.api) {
      for (var name in this.api.classes) {
        if (this.api.classes[name].tags.indexOf("Service") >= 0) { this.serviceNames.push(name); }
      }
      this.serviceNames.sort();
      this.globalIndex = Object.create(null);
      var g = this.api.globals;
      for (var p = 0; p < g.props.length; p++) { this.globalIndex[g.props[p][0]] = { kind: "p", row: g.props[p] }; }
      for (var f = 0; f < g.funcs.length; f++) { this.globalIndex[g.funcs[f][0]] = { kind: "f", row: g.funcs[f] }; }
    } else {
      this.globalIndex = Object.create(null);
    }
  }

  Resolver.prototype.ready = function () { return !!this.api; };

  Resolver.prototype.isClass = function (name) {
    return !!(this.api && this.api.classes[name]);
  };
  Resolver.prototype.isDatatype = function (name) {
    return !!(this.api && this.api.datatypes[name]);
  };
  Resolver.prototype.isEnum = function (name) {
    return !!(this.api && this.api.enums[name]);
  };

  // The bare names that are in no table: Roblox's own, and the two capitalised
  // legacy spellings that still work.
  var BARE_GLOBALS = {
    game: 1, Game: 1, workspace: 1, Workspace: 1, script: 1, plugin: 1,
    shared: 1, _G: 1, _ENV: 1, self: 1, Enum: 1, Enums: 1
  };

  /// Is this a name a script can read without defining it first?
  ///
  /// Everything this engine and this executor provide, and nothing else. The
  /// answer when the tables have not loaded is *yes*: a check that cannot see
  /// its own data must not accuse anyone. Used only by the diagnostics module,
  /// which has a dozen further reasons to stay quiet before it asks.
  Resolver.prototype.isKnownGlobal = function (name) {
    if (!this.api || !this.exec) { return true; }
    if (BARE_GLOBALS[name]) { return true; }
    if (this.globalIndex[name]) { return true; }
    if (this.api.libraries[name]) { return true; }
    if (this.api.datatypes[name]) { return true; }
    if (this.api.enums[name]) { return true; }
    if (this.execNames[name]) { return true; }
    if (this.execLibs[name]) { return true; }
    return false;
  };

  /// Does this namespace have this member? Only ever asked about a library, a
  /// datatype's constructor table, or Enum - never about an Instance, whose
  /// members depend on a game that is not on this machine.
  Resolver.prototype.hasMember = function (type, name) {
    if (!type || !this.api || !this.exec) { return true; }
    var key = type.k + ":" + (type.name || "");
    var set = this.memberSets[key];
    if (!set) {
      set = Object.create(null);
      var rows = this.membersOf(type, ".");
      for (var i = 0; i < rows.length; i++) { set[rows[i].name] = 1; }
      // `debug` and `task` are both Roblox libraries and executor libraries,
      // and globalType answers with the Roblox one - whose table is the
      // smaller. Without this union, debug.getupvalues is an unknown member.
      var ours = this.exec.libraries[type.name];
      if (ours) {
        for (var j = 0; j < ours.length; j++) { set[ours[j]] = 1; }
      }
      this.memberSets[key] = set;
    }
    return !!set[name];
  };

  // ------------------------------------------------------------------ types

  Resolver.prototype.argumentCall = function (name) {
    if (!Object.prototype.hasOwnProperty.call(ARGUMENT_CALLS, name)) { return null; }
    return ARGUMENT_CALLS[name] === "iter" ? "iter" : (ARGUMENT_CALLS[name] ? "self" : null);
  };

  /// A type written as text — from the API dump, or from an annotation in the
  /// file — as a type object.
  Resolver.prototype.typeFromString = function (text) {
    if (!text) { return ANY; }
    text = String(text).trim();
    if (text.charAt(text.length - 1) === "?") { text = text.slice(0, -1).trim(); }
    if (!text || text === "any" || text === "nil" || text === "()" ||
        text === "Variant" || text === "...any") { return ANY; }
    if (text.charAt(0) === "{" && text.charAt(text.length - 1) === "}") {
      var inner = text.slice(1, -1).trim();
      if (inner.indexOf(":") >= 0) { return { k: "table", fields: Object.create(null) }; }
      return { k: "array", of: this.typeFromString(inner) };
    }
    // A tuple return: the first value is the one a chain carries on from.
    var comma = text.indexOf(",");
    if (comma > 0) { return this.typeFromString(text.slice(0, comma)); }
    if (text.indexOf("Enum.") === 0) { return { k: "enumitem", name: text.slice(5) }; }
    if (text === "number" || text === "string" || text === "boolean" ||
        text === "thread" || text === "buffer" || text === "vector") { return prim(text); }
    if (text === "function") { return { k: "func" }; }
    if (this.isClass(text)) { return cls(text); }
    if (this.isDatatype(text)) { return { k: "datatype", name: text }; }
    return ANY;
  };

  /// A name as it appears in an annotation, which may also be a library.
  Resolver.prototype.typeFromName = function (name) {
    if (!name) { return null; }
    if (this.api && this.api.libraries[name]) { return { k: "lib", name: name }; }
    var type = this.typeFromString(name);
    return type === ANY ? null : type;
  };

  /// What a bare name at the top of a chain is.
  Resolver.prototype.globalType = function (name) {
    if (!this.api) { return ANY; }
    switch (name) {
      case "game":      return cls("DataModel");
      case "workspace": return cls("Workspace");
      case "Workspace": return cls("Workspace");
      case "script":    return cls("LocalScript");
      case "Enum":      return { k: "enums" };
      case "shared":
      case "_G":        return { k: "table", fields: Object.create(null) };
      case "self":      return ANY;
      default: break;
    }
    if (this.api.libraries[name]) { return { k: "lib", name: name }; }
    if (this.api.datatypes[name]) { return { k: "dtype", name: name }; }
    if (this.execLibs[name]) { return { k: "execlib", name: name }; }
    if (this.execNames[name]) { return { k: "func", exec: name }; }
    var known = this.globalIndex[name];
    if (known) {
      return known.kind === "p" ? this.typeFromString(known.row[1]) : { k: "func", global: name };
    }
    return ANY;
  };

  /// The flattened member table of a class, its ancestors included. Built once
  /// per class: `BasePart` alone answers for two hundred members and the list
  /// is walked on every keystroke that opens a suggestion.
  Resolver.prototype.classMembers = function (name) {
    if (this.memberCache[name]) { return this.memberCache[name]; }
    var table = Object.create(null);
    var chain = [];
    var current = name;
    var guard = 0;
    while (current && this.api.classes[current] && guard++ < 40) {
      chain.push(current);
      current = this.api.classes[current].super;
    }
    // Walked from the root down, so a subclass's own member wins.
    for (var i = chain.length - 1; i >= 0; i--) {
      var members = this.api.classes[chain[i]].members;
      for (var m = 0; m < members.length; m++) {
        table[members[m][0]] = { row: members[m], owner: chain[i] };
      }
    }
    this.memberCache[name] = table;
    return table;
  };

  /// `a.b` — the type of one member of whatever `a` is.
  Resolver.prototype.memberType = function (type, name) {
    if (!type || !this.api) { return ANY; }
    switch (type.k) {
      case "class": {
        var found = this.classMembers(type.name)[name];
        if (found) {
          var row = found.row;
          if (row[1] === "p") { return this.typeFromString(row[2]); }
          if (row[1] === "e") { return { k: "signal", cls: found.owner, member: name }; }
          return { k: "method", cls: type.name, name: name };
        }
        // Not a member: a child of that name, then. A child named after a
        // class almost always is one, which is what makes
        // `Character.Humanoid.WalkSpeed` complete.
        if (this.isClass(name)) { return cls(name, true); }
        return cls("Instance", true);
      }
      case "enums":     return this.isEnum(name) ? { k: "enum", name: name } : ANY;
      case "enum":      return { k: "enumitem", name: type.name };
      case "enumitem":
        if (name === "Name") { return prim("string"); }
        if (name === "Value") { return prim("number"); }
        if (name === "EnumType") { return { k: "enum", name: type.name }; }
        return ANY;
      case "dtype": {
        var dt = this.api.datatypes[type.name];
        if (!dt) { return ANY; }
        var ctor = find(dt.ctors, name);
        if (ctor) { return { k: "ctor", owner: type.name, name: name }; }
        var fn = find(dt.funcs, name);
        if (fn) { return { k: "dfunc", owner: type.name, name: name }; }
        var constant = find(dt.consts, name);
        if (constant) { return this.typeFromString(constant[1]); }
        return ANY;
      }
      case "datatype": {
        var value = this.api.datatypes[type.name];
        if (!value) { return ANY; }
        var prop = find(value.props, name);
        if (prop) { return this.typeFromString(prop[1]); }
        var method = find(value.methods, name);
        if (method) { return { k: "dmethod", owner: type.name, name: name }; }
        return ANY;
      }
      case "signal": {
        var signalType = this.api.datatypes.RBXScriptSignal;
        if (signalType && find(signalType.methods, name)) {
          return { k: "dmethod", owner: "RBXScriptSignal", name: name, signal: type };
        }
        return ANY;
      }
      case "lib": {
        var lib = this.api.libraries[type.name];
        if (!lib) { return ANY; }
        if (find(lib.funcs, name)) { return { k: "libfunc", owner: type.name, name: name }; }
        var lprop = find(lib.props, name);
        if (lprop) { return this.typeFromString(lprop[1]); }
        return ANY;
      }
      case "execlib":   return { k: "func", exec: type.name + "." + name };
      case "prim":
        if (type.name === "string") { return { k: "libfunc", owner: STRING_METHOD_OWNER, name: name }; }
        return ANY;
      case "table": {
        var field = type.fields && type.fields[name];
        return field ? (field.type || ANY) : ANY;
      }
      case "array":     return ANY;
      default:          return ANY;
    }
  };

  /// `a:b(...)` — the type a method call gives back.
  Resolver.prototype.callType = function (type, name, args) {
    if (!type || !this.api) { return ANY; }
    var first = args && args.length ? args[0] : null;

    if (type.k === "class") {
      if (IDENTITY_CALLS[name]) { return cls(type.name); }
      if (BY_ARGUMENT[name] && typeof first === "string") {
        if (this.isClass(first)) { return cls(first, BY_ARGUMENT[name] === "guess"); }
        return cls("Instance", true);
      }
      if (ARRAY_RETURNS[name]) { return { k: "array", of: cls(ARRAY_RETURNS[name]) }; }
      var member = this.classMembers(type.name)[name];
      if (member && member.row[1] === "f") { return this.typeFromString(member.row[2]); }
      return ANY;
    }
    if (type.k === "signal") {
      if (name === "Connect" || name === "ConnectParallel" || name === "Once") {
        return { k: "datatype", name: "RBXScriptConnection" };
      }
      if (name === "Wait") {
        var params = this.signalParameters(type);
        return params.length ? this.typeFromString(params[0][1]) : ANY;
      }
      return ANY;
    }
    if (type.k === "datatype") {
      var dt = this.api.datatypes[type.name];
      var method = dt && find(dt.methods, name);
      return method ? this.typeFromString(method[2]) : ANY;
    }
    if (type.k === "prim" && type.name === "string") {
      var strlib = this.api.libraries[STRING_METHOD_OWNER];
      var fn = strlib && find(strlib.funcs, name);
      return fn ? this.typeFromString(fn[2]) : ANY;
    }
    if (type.k === "table") {
      var field = type.fields && type.fields[name];
      return field && field.type ? ANY : ANY;
    }
    return ANY;
  };

  /// `f(...)` where `f` is whatever the chain produced.
  Resolver.prototype.plainCallType = function (type, args) {
    if (!type || !this.api) { return ANY; }
    var first = args && args.length ? args[0] : null;

    if (type.k === "ctor") {
      // `Instance.new("Part")` is the one constructor whose result depends on
      // what it was handed.
      if (type.owner === "Instance" && typeof first === "string" && this.isClass(first)) {
        return cls(first);
      }
      if (type.owner === "Instance") { return cls("Instance"); }
      return { k: "datatype", name: type.owner };
    }
    if (type.k === "dfunc") {
      var dt = this.api.datatypes[type.owner];
      var fn = dt && find(dt.funcs, type.name);
      return fn ? this.typeFromString(fn[2]) : { k: "datatype", name: type.owner };
    }
    if (type.k === "dmethod") {
      var owner = this.api.datatypes[type.owner];
      var method = owner && find(owner.methods, type.name);
      return method ? this.typeFromString(method[2]) : ANY;
    }
    if (type.k === "libfunc") {
      var lib = this.api.libraries[type.owner];
      var lf = lib && find(lib.funcs, type.name);
      return lf ? this.typeFromString(lf[2]) : ANY;
    }
    if (type.k === "method") {
      var member = this.classMembers(type.cls)[type.name];
      if (member && member.row[1] === "f") {
        if (BY_ARGUMENT[type.name] && typeof first === "string" && this.isClass(first)) {
          return cls(first, BY_ARGUMENT[type.name] === "guess");
        }
        if (ARRAY_RETURNS[type.name]) { return { k: "array", of: cls(ARRAY_RETURNS[type.name]) }; }
        return this.typeFromString(member.row[2]);
      }
      return ANY;
    }
    if (type.k === "func" && type.global) {
      var known = this.globalIndex[type.global];
      if (known && known.kind === "f") { return this.typeFromString(known.row[2]); }
      return ANY;
    }
    if (type.k === "func" && type.exec) { return this.execReturn(type.exec); }
    return ANY;
  };

  /// The executor's own return types, for the calls whose result is worth
  /// carrying on from. Everything else is `any`, which is honest.
  Resolver.prototype.execReturn = function (name) {
    switch (name) {
      case "gethui":            return cls("Folder", true);
      case "getgenv":
      case "getrenv":
      case "getsenv":
      case "getreg":
      case "getregistry":
      case "gettenv":           return { k: "table", fields: Object.create(null) };
      case "getinstances":
      case "getnilinstances":   return { k: "array", of: cls("Instance") };
      case "getscripts":
      case "getrunningscripts": return { k: "array", of: cls("BaseScript") };
      case "getloadedmodules":  return { k: "array", of: cls("ModuleScript") };
      case "getactors":         return { k: "array", of: cls("Actor") };
      case "getcallingscript":  return cls("BaseScript");
      case "getconnections":    return { k: "array", of: ANY };
      case "readfile":
      case "getcustomasset":
      case "identifyexecutor":
      case "getexecutorname":
      case "getclipboard":
      case "decompile":
      case "getscriptbytecode":
      case "dumpstring":
      case "getscripthash":
      case "gethwid":
      case "crypt_hash":        return prim("string");
      case "isfile":
      case "isfolder":
      case "checkcaller":
      case "iscclosure":
      case "islclosure":
      case "isexecutorclosure":
      case "isourclosure":
      case "checkclosure":
      case "isreadonly":
      case "isnewcclosure":
      case "isscriptable":
      case "ishiddenproperty":
      case "isrenderobj":
      case "isrbxactive":
      case "iswindowactive":
      case "isgameactive":
      case "compareinstances":
      case "isfunctionhooked":  return prim("boolean");
      case "getthreadidentity":
      case "getidentity":
      case "getfpscap":         return prim("number");
      case "listfiles":         return { k: "array", of: prim("string") };
      case "cloneref":
      case "clonereference":    return cls("Instance");
      default:                  return ANY;
    }
  };

  Resolver.prototype.indexType = function (type, key) {
    if (!type) { return ANY; }
    if (type.k === "array") { return type.of || ANY; }
    if (type.k === "table" && typeof key === "string" && type.fields && type.fields[key]) {
      return type.fields[key].type || ANY;
    }
    if (type.k === "class" && typeof key === "string") { return this.memberType(type, key); }
    return ANY;
  };

  /// `for a, b in <type>` — what each loop variable is.
  Resolver.prototype.iterationTypes = function (type, count) {
    var out = [];
    var source = type;
    if (type && type.k === "iter") { source = type.of; }
    if (source && source.k === "array") { out = [prim("number"), source.of || ANY]; }
    else if (source && source.k === "table") {
      var fields = source.fields || {};
      var only = null;
      var single = true;
      for (var key in fields) {
        if (only && fields[key].type !== only) { single = false; }
        only = only || fields[key].type;
      }
      out = [prim("string"), single && only ? only : ANY];
    } else { out = [ANY, ANY]; }
    while (out.length < count) { out.push(ANY); }
    return out;
  };

  /// The parameters an event hands its listener, which is what makes
  /// `PlayerAdded:Connect(function(player)` know what `player` is.
  Resolver.prototype.signalParameters = function (signal) {
    if (!signal || !this.api) { return []; }
    var member = this.classMembers(signal.cls)[signal.member];
    return member && member.row[3] ? member.row[3] : [];
  };

  // A function literal passed to one of these is a listener, and the signal it
  // is being connected to says what it will be called with.
  var CONNECTORS = { Connect: 1, ConnectParallel: 1, Once: 1, connect: 1 };

  /// The types of a function literal's parameters, worked out from the call it
  /// is an argument to. Null when the call says nothing.
  Resolver.prototype.parameterTypes = function (call, count) {
    if (!call || !this.api) { return null; }
    if (call.separator === ":" && CONNECTORS[call.name] && call.owner &&
        call.owner.k === "signal") {
      var params = this.signalParameters(call.owner);
      if (!params.length) { return null; }
      var out = [];
      for (var i = 0; i < count; i++) {
        out.push(params[i] ? this.typeFromString(params[i][1]) : null);
      }
      return out;
    }
    return null;
  };

  // The names Roblox's own API gives these types. A parameter that nothing
  // else has explained is far more useful typed by its name than left as
  // `any`: it is what makes `function(plr) plr.` offer a Player's members
  // inside a callback nothing could resolve.
  var PARAMETER_NAMES = {
    player: "Player", plr: "Player", localplayer: "Player", target: "Player",
    otherplayer: "Player", victim: "Player",
    character: "Model", char: "Model", model: "Model", rig: "Model",
    humanoid: "Humanoid", hum: "Humanoid",
    part: "BasePart", otherpart: "BasePart", hit: "BasePart", basepart: "BasePart",
    touched: "BasePart", root: "BasePart", hrp: "BasePart",
    instance: "Instance", inst: "Instance", child: "Instance", parent: "Instance",
    descendant: "Instance", object: "Instance", obj: "Instance",
    input: "InputObject", inputobject: "InputObject",
    camera: "Camera", tool: "Tool", gui: "GuiObject", frame: "Frame",
    button: "GuiButton", prompt: "ProximityPrompt", sound: "Sound",
    animation: "Animation", track: "AnimationTrack", team: "Team",
    connection: "RBXScriptConnection", signal: "RBXScriptSignal",
    remote: "RemoteEvent", event: "RemoteEvent", func: "RemoteFunction"
  };

  var PARAMETER_PRIMITIVES = {
    dt: "number", delta: "number", deltatime: "number", step: "number",
    count: "number", index: "number", i: "number", n: "number", amount: "number",
    alpha: "number", speed: "number", distance: "number", radius: "number",
    name: "string", text: "string", message: "string", path: "string",
    url: "string", key: "string", id: "string",
    enabled: "boolean", visible: "boolean", active: "boolean",
    gameprocessed: "boolean", gameprocessedevent: "boolean"
  };

  Resolver.prototype.typeFromParameterName = function (name) {
    if (!name || !this.api) { return null; }
    var lower = String(name).toLowerCase();
    var className = PARAMETER_NAMES[lower];
    if (className && this.isClass(className)) { return cls(className, true); }
    var primitive = PARAMETER_PRIMITIVES[lower];
    if (primitive) { return prim(primitive); }
    return null;
  };

  // ------------------------------------------------------------ presentation

  function find(rows, name) {
    if (!rows) { return null; }
    for (var i = 0; i < rows.length; i++) {
      if (rows[i][0] === name) { return rows[i]; }
    }
    return null;
  }

  function findAll(rows, name) {
    var out = [];
    if (!rows) { return out; }
    for (var i = 0; i < rows.length; i++) {
      if (rows[i][0] === name) { out.push(rows[i]); }
    }
    return out;
  }

  /// `(name: string, recursive: boolean?)`, with a default shown where the
  /// documentation gives one.
  function formatParams(params) {
    if (!params || !params.length) { return "()"; }
    var parts = [];
    for (var i = 0; i < params.length; i++) {
      var p = params[i];
      var text = p[0];
      if (p[1]) { text += ": " + p[1]; }
      if (p.length > 2 && p[2] !== undefined && p[2] !== "") { text += " = " + p[2]; }
      parts.push(text);
    }
    return "(" + parts.join(", ") + ")";
  }

  function withReturn(label, ret) {
    if (!ret || ret === "()" || ret === "nil" || ret === "void") { return label; }
    return label + ": " + ret;
  }

  Resolver.prototype.formatParams = formatParams;

  var KIND = {
    property: "Property", method: "Method", event: "Event", "function": "Function",
    field: "Field", "enum": "Enum", enummember: "EnumMember", "class": "Class",
    variable: "Variable", constant: "Constant", keyword: "Keyword",
    snippet: "Snippet", module: "Module", value: "Value"
  };
  Resolver.prototype.KIND = KIND;

  // ------------------------------------------------------- what things mean

  /// The full description of a name, from api-docs.js once it has loaded;
  /// the summary until then, or where there is nothing more to say.
  function longDoc(key, summary) {
    var docs = global.NEXA_API_DOCS;
    return (docs && docs[key]) || summary || "";
  }

  var SECURITY_NAMES = { R: "RobloxScriptSecurity", P: "PluginSecurity", L: "LocalUserSecurity" };

  /// What the dump does say about a member the documentation says nothing
  /// about: its kind, its owner, its tags and the security it sits behind.
  /// Every word is from the engine's own table, so none of it can be wrong,
  /// and it says plainly that this is all there is.
  function undocumentedMember(owner, row) {
    var tags = row[5] || [];
    var kind = row[1] === "p" ? "property" : (row[1] === "e" ? "event" : (row[1] === "c" ? "callback" : "method"));
    var qualifiers = [];
    if (tags.indexOf("Deprecated") >= 0) { qualifiers.push("deprecated"); }
    if (tags.indexOf("Hidden") >= 0) { qualifiers.push("hidden"); }
    if (tags.indexOf("ReadOnly") >= 0) { qualifiers.push("read-only"); }
    if (tags.indexOf("NotScriptable") >= 0) { qualifiers.push("not-scriptable"); }
    var head = qualifiers.length ? qualifiers.join(", ") + " " + kind : kind;
    var text = (/^[aeiou]/.test(head) ? "An " : "A ") + head + " of `" + owner + "`";
    if (row[4] === "X") { text += ", not reachable from a script"; }
    else if (SECURITY_NAMES[row[4]]) { text += ", behind " + SECURITY_NAMES[row[4]]; }
    return text + ". Roblox does not document it.";
  }

  /// The sentence for a member: the documentation's, in full once api-docs.js
  /// is in, or what the dump says when the documentation has nothing.
  function memberDoc(owner, name, row) {
    return longDoc(owner + "." + name, row[6]) || undocumentedMember(owner, row);
  }

  function undocumentedClass(entry) {
    var tags = entry.tags || [];
    var text = tags.indexOf("Service") >= 0 ? "A service Roblox does not document."
                                             : "A class Roblox does not document.";
    if (tags.indexOf("Service") < 0 && tags.indexOf("NotCreatable") >= 0) {
      text += " It cannot be created with `Instance.new`.";
    }
    if (tags.indexOf("Deprecated") >= 0) { text += " Deprecated."; }
    if (entry.super && entry.super !== "<<<ROOT>>>") { text += " Inherits `" + entry.super + "`."; }
    return text;
  }

  function classDoc(name, entry) {
    return longDoc(name, entry.sum) || undocumentedClass(entry);
  }

  function enumDoc(name, entry) {
    var n = entry.items ? entry.items.length : 0;
    return longDoc("Enum." + name, entry.sum) ||
      ("An enumeration of " + n + (n === 1 ? " item" : " items") + " that Roblox does not document.");
  }

  /// One enum item: [name, value, summary, tags].
  function enumItemDoc(enumName, item) {
    return item[2] || ("Item " + item[1] + " of `Enum." + enumName + "`; Roblox does not describe it.");
  }

  function enumItemNote(item) {
    return "value " + item[1] + ((item[3] || []).indexOf("Deprecated") >= 0 ? " · deprecated" : "");
  }

  /// Everything that can follow `.` or `:` on a value of this type.
  ///
  /// `separator` matters: `:` is a method call, so only functions belong
  /// there; `.` can reach anything. Deprecated members, hidden ones and the
  /// ones behind a security level are all offered — an executor runs at an
  /// identity that can use them — but they sort below the rest.
  Resolver.prototype.membersOf = function (type, separator) {
    var out = [];
    if (!type || !this.api) { return out; }
    var method = separator === ":";

    switch (type.k) {
      case "class": {
        var table = this.classMembers(type.name);
        for (var name in table) {
          var row = table[name].row;
          var isFunction = row[1] === "f";
          if (method && !isFunction) { continue; }
          var tags = row[5] || [];
          var deprecated = tags.indexOf("Deprecated") >= 0;
          var hidden = tags.indexOf("Hidden") >= 0;
          var unscriptable = tags.indexOf("NotScriptable") >= 0;
          // Ordinary members first, then the ones that need something of the
          // executor to reach: an identity, or `setscriptable`. They are all
          // offered - reaching them is the point of the tool - but a plain
          // property should never be buried under them.
          var group = deprecated || hidden ? "6"
            : (unscriptable ? "5" : (row[4] ? "4"
              : (row[1] === "p" ? "1" : (row[1] === "e" ? "2" : "3"))));
          out.push({
            name: name,
            kind: row[1] === "p" ? "property" : (row[1] === "e" ? "event" : (row[1] === "c" ? "event" : "method")),
            detail: this.memberLabel(type.name, name, row)
              + (unscriptable ? "   · setscriptable" : ""),
            doc: memberDoc(table[name].owner, name, row),
            note: noteFor(table[name].owner, tags, row[4], row),
            sort: group + name,
            deprecated: deprecated,
            call: isFunction,
            params: isFunction ? row[3] : null
          });
        }
        return out;
      }
      case "enums": {
        for (var e in this.api.enums) {
          var en = this.api.enums[e];
          out.push({
            name: e, kind: "enum", detail: "Enum." + e, doc: enumDoc(e, en),
            deprecated: (en.tags || []).indexOf("Deprecated") >= 0, sort: "1" + e
          });
        }
        return out;
      }
      case "enum": {
        var entry = this.api.enums[type.name];
        var items = entry ? entry.items : [];
        for (var i = 0; i < items.length; i++) {
          var item = items[i];
          out.push({
            name: item[0], kind: "enummember",
            detail: "Enum." + type.name + "." + item[0] + " · " + enumItemNote(item),
            doc: enumItemDoc(type.name, item),
            deprecated: (item[3] || []).indexOf("Deprecated") >= 0,
            sort: "1" + item[0]
          });
        }
        return out;
      }
      case "enumitem":
        if (method) { return out; }
        out.push({ name: "Name", kind: "property", detail: "string", doc: "The item's name.", sort: "1Name" });
        out.push({ name: "Value", kind: "property", detail: "number", doc: "The item's numeric value.", sort: "1Value" });
        out.push({ name: "EnumType", kind: "property", detail: "Enum", doc: "The Enum this item belongs to.", sort: "1EnumType" });
        return out;
      case "dtype": {
        var dt = this.api.datatypes[type.name];
        if (!dt) { return out; }
        for (var c = 0; c < dt.ctors.length; c++) {
          var ctor = dt.ctors[c];
          if (findIn(out, ctor[0])) { continue; }
          out.push({
            name: ctor[0], kind: "method",
            detail: withReturn(type.name + "." + ctor[0] + formatParams(ctor[1]), ctor[2]),
            doc: longDoc(type.name + "." + ctor[0], ctor[3]), sort: "1" + ctor[0], call: true, params: ctor[1]
          });
        }
        for (var f = 0; f < dt.funcs.length; f++) {
          var fn = dt.funcs[f];
          if (findIn(out, fn[0])) { continue; }
          out.push({
            name: fn[0], kind: "method",
            detail: withReturn(type.name + "." + fn[0] + formatParams(fn[1]), fn[2]),
            doc: longDoc(type.name + "." + fn[0], fn[3]), sort: "2" + fn[0], call: true, params: fn[1]
          });
        }
        if (!method) {
          for (var k = 0; k < dt.consts.length; k++) {
            out.push({
              name: dt.consts[k][0], kind: "constant",
              detail: dt.consts[k][1], doc: longDoc(type.name + "." + dt.consts[k][0], dt.consts[k][2]),
              sort: "3" + dt.consts[k][0]
            });
          }
        }
        return out;
      }
      case "datatype": {
        var value = this.api.datatypes[type.name];
        if (!value) { return out; }
        if (!method) {
          for (var p = 0; p < value.props.length; p++) {
            out.push({
              name: value.props[p][0], kind: "property",
              detail: value.props[p][1], doc: longDoc(type.name + "." + value.props[p][0], value.props[p][2]),
              sort: "1" + value.props[p][0]
            });
          }
        }
        for (var m = 0; m < value.methods.length; m++) {
          var mm = value.methods[m];
          out.push({
            name: mm[0], kind: "method",
            detail: withReturn(type.name + ":" + mm[0] + formatParams(mm[1]), mm[2]),
            doc: longDoc(type.name + "." + mm[0], mm[3]), sort: "2" + mm[0], call: true, params: mm[1]
          });
        }
        return out;
      }
      case "signal":
        return this.membersOf({ k: "datatype", name: "RBXScriptSignal" }, separator);
      case "prim":
        if (type.name === "string") {
          return this.membersOf({ k: "lib", name: STRING_METHOD_OWNER }, separator);
        }
        return out;
      case "lib": {
        var lib = this.api.libraries[type.name];
        if (!lib) { return out; }
        for (var lf = 0; lf < lib.funcs.length; lf++) {
          var lfn = lib.funcs[lf];
          // An overload is one row per signature; a suggestion is one per name.
          if (findIn(out, lfn[0])) { continue; }
          out.push({
            name: lfn[0], kind: "function",
            detail: withReturn(type.name + "." + lfn[0] + formatParams(lfn[1]), lfn[2]),
            doc: longDoc(type.name + "." + lfn[0], lfn[3]), sort: "1" + lfn[0], call: true, params: lfn[1]
          });
        }
        if (!method) {
          for (var lp = 0; lp < lib.props.length; lp++) {
            out.push({
              name: lib.props[lp][0], kind: "constant",
              detail: lib.props[lp][1], doc: longDoc(type.name + "." + lib.props[lp][0], lib.props[lp][2]),
              sort: "2" + lib.props[lp][0]
            });
          }
        }
        // `debug` is both Roblox's library and this executor's, and the
        // executor's half - getupvalues, getconstants, the ones every script
        // reaches for - is described by executor-docs.js, not the tables.
        var ours = this.execLibs[type.name];
        if (ours) {
          for (var o = 0; o < ours.length; o++) {
            if (findIn(out, ours[o])) { continue; }
            var full = type.name + "." + ours[o];
            var edoc = this.docs[full];
            out.push({
              name: ours[o], kind: "function",
              detail: edoc ? edoc[0] : full, doc: edoc ? edoc[1] : "Provided by the executor.",
              note: "this executor", sort: "1" + ours[o], call: true
            });
          }
        }
        return out;
      }
      case "execlib": {
        var members = this.execLibs[type.name] || [];
        for (var x = 0; x < members.length; x++) {
          var full = type.name + "." + members[x];
          var doc = this.docs[full];
          out.push({
            name: members[x], kind: "function",
            detail: doc ? doc[0] : full, doc: doc ? doc[1] : "Provided by the executor.",
            sort: "1" + members[x], call: true
          });
        }
        return out;
      }
      case "table": {
        var fields = type.fields || {};
        for (var key in fields) {
          var field = fields[key];
          out.push({
            name: key,
            kind: field.kind === "function" ? "method" : "field",
            detail: field.params ? key + "(" + field.params.join(", ") + ")"
                                 : (Lex ? Lex.typeLabel(field.type) : "field"),
            doc: "", sort: "1" + key, call: field.kind === "function", params: null
          });
        }
        return out;
      }
      default:
        return out;
    }
  };

  function findIn(list, name) {
    for (var i = 0; i < list.length; i++) { if (list[i].name === name) { return true; } }
    return false;
  }

  Resolver.prototype.memberLabel = function (className, name, row) {
    if (row[1] === "p") { return row[2]; }
    if (row[1] === "e") { return className + "." + name + formatParams(row[3]); }
    return withReturn(className + ":" + name + formatParams(row[3]), row[2]);
  };

  /// The one-line signature and sentence shown on hover, for whatever a chain
  /// resolved to.
  Resolver.prototype.describeMember = function (ownerType, name) {
    if (!ownerType || !this.api) { return null; }
    if (ownerType.k === "class") {
      var found = this.classMembers(ownerType.name)[name];
      if (!found) { return null; }
      var tags = found.row[5] || [];
      return {
        // A property's label beside a suggestion is its type alone; on its
        // own card it needs its name too.
        label: found.row[1] === "p" ? found.owner + "." + name + ": " + found.row[2]
                                    : this.memberLabel(found.owner, name, found.row),
        doc: memberDoc(found.owner, name, found.row),
        note: noteFor(found.owner, tags, found.row[4], found.row)
      };
    }
    if (ownerType.k === "dtype" || ownerType.k === "datatype") {
      var dt = this.api.datatypes[ownerType.name];
      if (!dt) { return null; }
      var rows = findAll(dt.ctors, name).concat(findAll(dt.funcs, name));
      if (rows.length) {
        return {
          label: rows.map(function (r) {
            return withReturn(ownerType.name + "." + name + formatParams(r[1]), r[2] || ownerType.name);
          }).join("\n"),
          doc: longDoc(ownerType.name + "." + name, rows[0][3])
        };
      }
      var method = find(dt.methods, name);
      if (method) {
        return {
          label: withReturn(ownerType.name + ":" + name + formatParams(method[1]), method[2]),
          doc: longDoc(ownerType.name + "." + name, method[3])
        };
      }
      var prop = find(dt.props, name) || find(dt.consts, name);
      if (prop) {
        return { label: ownerType.name + "." + name + ": " + prop[1], doc: longDoc(ownerType.name + "." + name, prop[2]) };
      }
      return null;
    }
    if (ownerType.k === "lib") {
      var lib = this.api.libraries[ownerType.name];
      if (!lib) { return null; }
      var lfn = find(lib.funcs, name);
      if (lfn) {
        return {
          label: withReturn(ownerType.name + "." + name + formatParams(lfn[1]), lfn[2]),
          doc: longDoc(ownerType.name + "." + name, lfn[3])
        };
      }
      var lprop = find(lib.props, name);
      if (lprop) {
        return { label: ownerType.name + "." + name + ": " + lprop[1], doc: longDoc(ownerType.name + "." + name, lprop[2]) };
      }
      // Not Roblox's: the executor's, in a library the two share.
      var shared = this.docs[ownerType.name + "." + name];
      if (shared) { return { label: shared[0], doc: shared[1], note: "this executor" }; }
      var ours = this.execLibs[ownerType.name];
      if (ours && ours.indexOf(name) >= 0) {
        return { label: ownerType.name + "." + name + "(…)", doc: "Provided by the executor.", note: "this executor" };
      }
      return null;
    }
    if (ownerType.k === "enums") {
      var en = this.api.enums[name];
      return en ? { label: "Enum." + name, doc: enumDoc(name, en),
                    note: (en.tags || []).indexOf("Deprecated") >= 0 ? "deprecated" : null } : null;
    }
    if (ownerType.k === "enum") {
      var owner = this.api.enums[ownerType.name];
      var item = owner && find(owner.items, name);
      if (!item) { return null; }
      return { label: "Enum." + ownerType.name + "." + name, doc: enumItemDoc(ownerType.name, item), note: enumItemNote(item) };
    }
    if (ownerType.k === "execlib") {
      var doc = this.docs[ownerType.name + "." + name];
      return doc ? { label: doc[0], doc: doc[1] }
                 : { label: ownerType.name + "." + name, doc: "Provided by the executor." };
    }
    return null;
  };

  function noteFor(owner, tags, security, row) {
    var notes = [];
    // A property's default, as the engine reports it.
    if (row && row[1] === "p" && row[3] !== null && row[3] !== undefined && row[3] !== "") {
      notes.push("default " + row[3]);
    }
    if (tags.indexOf("NotScriptable") >= 0) {
      notes.push("not scriptable — reach it with `setscriptable` or `gethiddenproperty`");
    }
    if (tags.indexOf("Deprecated") >= 0) { notes.push("deprecated"); }
    if (tags.indexOf("ReadOnly") >= 0) { notes.push("read-only"); }
    if (tags.indexOf("Yields") >= 0) { notes.push("yields"); }
    if (security === "R") { notes.push("RobloxScriptSecurity"); }
    else if (security === "P") { notes.push("PluginSecurity"); }
    else if (security === "L") { notes.push("LocalUserSecurity"); }
    else if (security === "X") { notes.push("not reachable from a script"); }
    if (owner) { notes.push("from " + owner); }
    return notes.join(" · ");
  }

  /// A bare global name — for hover, and for the completion list's detail.
  Resolver.prototype.describeGlobal = function (name) {
    var doc = this.docs[name];
    if (doc) { return { label: doc[0], doc: doc[1], exec: true }; }
    if (this.execNames[name]) {
      var sig = this.exec && this.exec.signatures ? this.exec.signatures[name] : null;
      var alias = this.exec && this.exec.aliases ? this.exec.aliases[name] : null;
      return {
        label: name + (sig ? "(" + sig.join(", ") + ")" : "(…)"),
        doc: alias ? "The executor's own. Another name for `" + alias + "`." : "Provided by the executor.",
        exec: true
      };
    }
    if (this.execLibs[name]) {
      return { label: name, doc: "An executor library: " + this.execLibs[name].join(", ") + ".", exec: true };
    }
    if (!this.api) { return null; }
    var known = this.globalIndex[name];
    if (known) {
      var row = known.row;
      if (known.kind === "p") {
        return { label: row[1] ? name + ": " + row[1] : name, doc: longDoc(name, row[2]) };
      }
      return { label: withReturn(name + formatParams(row[1]), row[2]), doc: longDoc(name, row[3]) };
    }
    if (this.api.libraries[name]) {
      return { label: name, doc: longDoc(name, this.api.libraries[name].sum), note: "Luau library" };
    }
    if (this.api.datatypes[name]) {
      return { label: name, doc: longDoc(name, this.api.datatypes[name].sum), note: "datatype" };
    }
    if (this.isClass(name)) {
      var entry = this.api.classes[name];
      return { label: name, doc: classDoc(name, entry),
               note: entry.tags.indexOf("Service") >= 0 ? "service" : "class" };
    }
    return null;
  };

  /// The parameter list to show while a call is being typed.
  Resolver.prototype.signatureFor = function (call) {
    if (!this.api || !call) { return null; }
    var name = call.name;

    if (call.separator && call.owner) {
      var owner = call.owner;
      if (owner.k === "class") {
        var found = this.classMembers(owner.name)[name];
        if (found && (found.row[1] === "f" || found.row[1] === "e")) {
          return { label: this.memberLabel(found.owner, name, found.row), params: found.row[3] || [], doc: found.row[6] };
        }
        return null;
      }
      if (owner.k === "signal") {
        var connect = find((this.api.datatypes.RBXScriptSignal || {}).methods, name);
        if (connect) {
          return {
            label: withReturn("RBXScriptSignal:" + name + formatParams(connect[1]), connect[2]),
            params: connect[1], doc: connect[3]
          };
        }
        return null;
      }
      if (owner.k === "dtype" || owner.k === "datatype") {
        var dt = this.api.datatypes[owner.name];
        if (!dt) { return null; }
        var rows = findAll(dt.ctors, name).concat(findAll(dt.funcs, name), findAll(dt.methods, name));
        if (!rows.length) { return null; }
        // Overloads: the one with room for the argument being typed.
        var pick = rows[0];
        for (var r = 0; r < rows.length; r++) {
          if ((rows[r][1] || []).length > call.argument) { pick = rows[r]; break; }
        }
        var joiner = find(dt.methods, name) ? ":" : ".";
        return {
          label: withReturn(owner.name + joiner + name + formatParams(pick[1]), pick[2]),
          params: pick[1], doc: pick[3], overloads: rows.length
        };
      }
      if (owner.k === "lib") {
        var lib = this.api.libraries[owner.name];
        var lfn = lib && find(lib.funcs, name);
        if (!lfn) {
          // The executor's half of a shared library (debug.getupvalues).
          var shared = this.docs[owner.name + "." + name];
          return shared ? { label: shared[0], params: paramsFromLabel(shared[0]), doc: shared[1] } : null;
        }
        return {
          label: withReturn(owner.name + "." + name + formatParams(lfn[1]), lfn[2]),
          params: lfn[1], doc: lfn[3]
        };
      }
      if (owner.k === "execlib") {
        var doc = this.docs[owner.name + "." + name];
        return doc ? { label: doc[0], params: [], doc: doc[1] } : null;
      }
      if (owner.k === "prim" && owner.name === "string") {
        var strlib = this.api.libraries[STRING_METHOD_OWNER];
        var sfn = strlib && find(strlib.funcs, name);
        if (!sfn) { return null; }
        // A method call passes the string as the first argument implicitly.
        return {
          label: withReturn("string:" + name + formatParams(sfn[1].slice(1)), sfn[2]),
          params: sfn[1].slice(1), doc: sfn[3]
        };
      }
      return null;
    }

    // A bare call: a local, an executor function, or a Luau global.
    if (call.local && call.local.params) {
      return {
        label: call.name + "(" + call.local.params.join(", ") + ")",
        params: call.local.params.map(function (p) { return [p, ""]; }),
        doc: "Defined in this file."
      };
    }
    var described = this.docs[name];
    if (described) {
      return { label: described[0], params: paramsFromLabel(described[0]), doc: described[1] };
    }
    if (this.execNames[name]) {
      var sig = this.exec && this.exec.signatures ? this.exec.signatures[name] : null;
      if (sig) {
        return {
          label: name + "(" + sig.join(", ") + ")",
          params: sig.map(function (p) { return [p, ""]; }),
          doc: "Provided by the executor."
        };
      }
      return null;
    }
    var g = this.globalIndex[name];
    if (g && g.kind === "f") {
      return { label: withReturn(name + formatParams(g.row[1]), g.row[2]), params: g.row[1], doc: g.row[3] };
    }
    return null;
  };

  /// Parameter ranges out of a hand-written signature, so the hint can
  /// highlight the argument being typed.
  function paramsFromLabel(label) {
    var open = label.indexOf("(");
    var close = label.lastIndexOf(")");
    if (open < 0 || close < open) { return []; }
    var inner = label.slice(open + 1, close);
    if (!inner.trim()) { return []; }
    var parts = [];
    var depth = 0, start = 0;
    for (var i = 0; i < inner.length; i++) {
      var c = inner.charAt(i);
      if (c === "(" || c === "{" || c === "[") { depth++; }
      else if (c === ")" || c === "}" || c === "]") { depth--; }
      else if (c === "," && depth === 0) { parts.push(inner.slice(start, i)); start = i + 1; }
    }
    parts.push(inner.slice(start));
    return parts.map(function (p) {
      var text = p.trim();
      var colon = text.indexOf(":");
      return colon > 0 ? [text.slice(0, colon).trim(), text.slice(colon + 1).trim()] : [text, ""];
    });
  }

  Resolver.prototype.paramsFromLabel = paramsFromLabel;

  // The names a string argument can usefully be completed with.
  Resolver.prototype.stringChoices = function (call) {
    if (!this.api || !call) { return null; }
    var name = call.name;
    if (name === "GetService" || name === "FindService" || name === "getService") {
      return { list: this.serviceNames, kind: "class", detail: "service" };
    }
    if (name === "new" && call.owner && call.owner.k === "dtype" && call.owner.name === "Instance") {
      return { list: this.creatableClasses(), kind: "class", detail: "class" };
    }
    if (name === "IsA" || name === "FindFirstChildWhichIsA" || name === "FindFirstAncestorWhichIsA" ||
        name === "FindFirstChildOfClass" || name === "FindFirstAncestorOfClass" ||
        name === "GetPropertyChangedSignal" || name === "fromExisting") {
      if (name === "GetPropertyChangedSignal") {
        var owner = call.owner;
        if (owner && owner.k === "class") {
          var out = [];
          var table = this.classMembers(owner.name);
          for (var key in table) { if (table[key].row[1] === "p") { out.push(key); } }
          out.sort();
          return { list: out, kind: "property", detail: "property" };
        }
        return null;
      }
      return { list: this.allClasses(), kind: "class", detail: "class" };
    }
    return null;
  };

  Resolver.prototype.allClasses = function () {
    if (this.flatCache.all) { return this.flatCache.all; }
    var out = Object.keys(this.api.classes).sort();
    this.flatCache.all = out;
    return out;
  };

  Resolver.prototype.creatableClasses = function () {
    if (this.flatCache.creatable) { return this.flatCache.creatable; }
    var out = [];
    for (var name in this.api.classes) {
      if (this.api.classes[name].tags.indexOf("NotCreatable") < 0) { out.push(name); }
    }
    out.sort();
    this.flatCache.creatable = out;
    return out;
  };

  // ------------------------------------------------------------------ export

  global.LuauResolve = {
    create: function () { return new Resolver(); },
    formatParams: formatParams,
    withReturn: withReturn
  };

})(typeof window !== "undefined" ? window : globalThis);
